//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-E4asCEtG.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/login",
			"/api/auth/$"
		],
		preloads: ["/assets/index-DYRHL9SW.js", "/assets/react-DB-4Zxce.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-DYRHL9SW.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-CaVDonoJ.js", "/assets/client-CzaTc0Rp.js"]
	},
	"/login": {
		filePath: "/workspace/src/routes/login.tsx",
		children: void 0,
		preloads: ["/assets/login-BgVcuIPL.js", "/assets/client-CzaTc0Rp.js"]
	}
} });
//#endregion
export { tsrStartManifest };
