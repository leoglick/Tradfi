import { n as createMiddleware } from "./ssr.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/quotes-yP9O0pTE.js
/**
* Auth middleware for server functions — the standard way to get the caller's
* verified user id. When deployed the session cookie is same-origin and rides
* along automatically. In the live preview the client also forwards the bearer
* token (partitioned cookies) via the `.client` hook below — call sites do not
* thread it themselves.
*
*   import { createServerFn } from "@tanstack/react-start";
*   import { getSql } from "@/lib/db";
*   import { authMiddleware } from "@/lib/auth/middleware";
*
*   export const listTodos = createServerFn({ method: "GET" })
*     .middleware([authMiddleware])
*     .handler(async ({ context }) => {
*       const sql = await getSql();
*       return sql`select * from todos where user_id = ${context.userId}`;
*     });
*
* Signed out with auth on (live preview included) -> throws `UnauthorizedError`
* (see `verify.server.ts`). With auth disabled (`VITE_AUTH_ENABLED=false`, the
* shipped default) it resolves the shared dev user — but throws instead when a
* `DATABASE_URL` is also set, so an app without sign-in must not use this at
* all. On the auth-on path, use it on every server function that touches
* per-user data and scope every query by `context.userId`.
*/
var authMiddleware = createMiddleware({ type: "function" }).client(async ({ next }) => {
	const { getBearerToken } = await import("./client-IWHfIGH2.mjs").then((n) => n.n);
	return next({ sendContext: { bearerToken: getBearerToken() ?? void 0 } });
}).server(async ({ next, context }) => {
	const { assertSameSiteRequest } = await import("./isolation.server-CGNg1r0B.mjs");
	const { requireUserId } = await import("./verify.server-BBZ-MTLX.mjs");
	assertSameSiteRequest();
	return next({ context: { userId: await requireUserId(context.bearerToken) } });
});
var DOMAINS = [
	{
		id: "futures",
		label: "Futures",
		armed: "Futures armed",
		blurb: "BTC, ETH, and SOL futures. Defined stops, one attempt."
	},
	{
		id: "forex",
		label: "Forex",
		armed: "Forex armed",
		blurb: "Majors and gold. Tight risk, timed to the session."
	},
	{
		id: "degen",
		label: "Degen",
		armed: "Degen armed",
		blurb: "High-variance perps. Size is capped. Invalidation is close."
	}
];
var CORE = [
	{
		id: "btc-usd",
		domain: "futures",
		symbol: "BTC/USD",
		market: "Futures",
		direction: "long",
		entry: 84100,
		tp: 86800,
		sl: 82840,
		confidence: 74,
		timeframe: "1H",
		session: "UTC",
		thesis: "Bitcoin futures are holding the session shelf. Target the next round number. Invalid if that shelf breaks.",
		decimals: 2,
		sizeLabel: "BTC",
		dollarsPerUnit: 1,
		notionalPerUnit: 84100
	},
	{
		id: "eth-usd",
		domain: "futures",
		symbol: "ETH/USD",
		market: "Futures",
		direction: "long",
		entry: 2668,
		tp: 2784,
		sl: 2612,
		confidence: 71,
		timeframe: "1H",
		session: "UTC",
		thesis: "Ether is bid with bitcoin. First scale at the measured move. Stop sits under the session low.",
		decimals: 2,
		sizeLabel: "ETH",
		dollarsPerUnit: 1,
		notionalPerUnit: 2668
	},
	{
		id: "sol-usd",
		domain: "futures",
		symbol: "SOL/USD",
		market: "Futures",
		direction: "short",
		entry: 118.1,
		tp: 112.4,
		sl: 120.6,
		confidence: 68,
		timeframe: "15m",
		session: "UTC",
		thesis: "Sol failed the local high and is the weak leg. Cover into the prior shelf. Cancel if the high is reclaimed.",
		decimals: 2,
		sizeLabel: "SOL",
		dollarsPerUnit: 1,
		notionalPerUnit: 118.1
	},
	{
		id: "eurusd-long",
		domain: "forex",
		symbol: "EURUSD",
		market: "Forex",
		direction: "long",
		entry: 1.0864,
		tp: 1.0912,
		sl: 1.08406,
		confidence: 78,
		timeframe: "4H",
		session: "London",
		thesis: "Bids are defending the 1.0840 shelf. 4H structure is a higher low. Target the prior week high before the New York cut.",
		decimals: 5,
		sizeLabel: "lots",
		dollarsPerUnit: 1e5,
		notionalPerUnit: 108640
	},
	{
		id: "gbpusd-short",
		domain: "forex",
		symbol: "GBPUSD",
		market: "Forex",
		direction: "short",
		entry: 1.2715,
		tp: 1.2644,
		sl: 1.2748,
		confidence: 74,
		timeframe: "1H",
		session: "New York",
		thesis: "Sterling failed the London high and rolled under session VWAP. Short into the Asia low. Cancel if New York reclaims the high.",
		decimals: 5,
		sizeLabel: "lots",
		dollarsPerUnit: 1e5,
		notionalPerUnit: 127150
	},
	{
		id: "usdjpy-long",
		domain: "forex",
		symbol: "USDJPY",
		market: "Forex",
		direction: "long",
		entry: 151.42,
		tp: 152.545,
		sl: 150.89,
		confidence: 77,
		timeframe: "4H",
		session: "Tokyo",
		thesis: "Dip was bought at the 4H demand and carry still leans long. Target the range high. Stand down around intervention headlines.",
		decimals: 3,
		sizeLabel: "lots",
		dollarsPerUnit: 660.4,
		notionalPerUnit: 1e5
	},
	{
		id: "xauusd-long",
		domain: "forex",
		symbol: "XAUUSD",
		market: "Forex",
		direction: "long",
		entry: 2654.3,
		tp: 2690.18,
		sl: 2636.8,
		confidence: 75,
		timeframe: "1H",
		session: "London",
		thesis: "Gold held the breakout retest and London is printing higher lows. First scale at the measured move. Stop under the retest wick.",
		decimals: 2,
		sizeLabel: "oz",
		dollarsPerUnit: 1,
		notionalPerUnit: 2654.3
	},
	{
		id: "sol-long",
		domain: "degen",
		symbol: "SOL",
		market: "Perp",
		direction: "long",
		entry: 178.4,
		tp: 179.57,
		sl: 177.95,
		confidence: 64,
		timeframe: "15m",
		session: "UTC",
		thesis: "Perp range break with light open interest. Invalidation is tight on purpose — a sleeve, not a core book. No averaging down.",
		decimals: 2,
		sizeLabel: "SOL",
		dollarsPerUnit: 1,
		notionalPerUnit: 178.4
	},
	{
		id: "wif-long",
		domain: "degen",
		symbol: "WIF",
		market: "Perp",
		direction: "long",
		entry: 1.864,
		tp: 1.878,
		sl: 1.8593,
		confidence: 61,
		timeframe: "5m",
		session: "UTC",
		thesis: "Momentum scalp above the local base. Funding is hot, so the stop is close and the target is modest. One attempt only.",
		decimals: 4,
		sizeLabel: "WIF",
		dollarsPerUnit: 1,
		notionalPerUnit: 1.864
	},
	{
		id: "pepe-long",
		domain: "degen",
		symbol: "PEPE",
		market: "Perp",
		direction: "long",
		entry: 984e-8,
		tp: 988e-8,
		sl: 982e-8,
		confidence: 58,
		timeframe: "5m",
		session: "UTC",
		thesis: "Meme impulse, not a thesis. Trade the burst or get out. Size stays inside the degen cap no matter how loud the tape gets.",
		decimals: 8,
		sizeLabel: "PEPE",
		dollarsPerUnit: 1,
		notionalPerUnit: 984e-8
	},
	{
		id: "doge-short",
		domain: "degen",
		symbol: "DOGE",
		market: "Perp",
		direction: "short",
		entry: .1642,
		tp: .16317,
		sl: .16461,
		confidence: 60,
		timeframe: "15m",
		session: "UTC",
		thesis: "Failed push into supply and perps are leaning long into it. Fade back to the session open. Cover fast if the high breaks.",
		decimals: 5,
		sizeLabel: "DOGE",
		dollarsPerUnit: 1,
		notionalPerUnit: .1642
	},
	{
		id: "audusd-short",
		domain: "forex",
		symbol: "AUDUSD",
		market: "Forex",
		direction: "short",
		entry: .6628,
		tp: .6592,
		sl: .6645,
		confidence: 72,
		timeframe: "1H",
		session: "London",
		thesis: "Aussie rolled over with the commodity complex and lost the London open. Target the Asia low.",
		decimals: 5,
		sizeLabel: "lots",
		dollarsPerUnit: 1e5,
		notionalPerUnit: 66280
	},
	{
		id: "usdcad-long",
		domain: "forex",
		symbol: "USDCAD",
		market: "Forex",
		direction: "long",
		entry: 1.3586,
		tp: 1.3645,
		sl: 1.3558,
		confidence: 66,
		timeframe: "4H",
		session: "New York",
		thesis: "Higher low against the oil dip. Not triggered until price reclaims the session open.",
		decimals: 5,
		sizeLabel: "lots",
		dollarsPerUnit: 1e5,
		notionalPerUnit: 1e5
	},
	{
		id: "nzdusd-long",
		domain: "forex",
		symbol: "NZDUSD",
		market: "Forex",
		direction: "long",
		entry: .5974,
		tp: .6016,
		sl: .5954,
		confidence: 70,
		timeframe: "1H",
		session: "Tokyo",
		thesis: "Kiwi completed the measured move off the Asia base. Target was hit. Stand aside.",
		decimals: 5,
		sizeLabel: "lots",
		dollarsPerUnit: 1e5,
		notionalPerUnit: 59740
	},
	{
		id: "sui-long",
		domain: "degen",
		symbol: "SUI",
		market: "Perp",
		direction: "long",
		entry: 2.184,
		tp: 2.1972,
		sl: 2.1785,
		confidence: 63,
		timeframe: "5m",
		session: "UTC",
		thesis: "Clean 5m break with the stop almost on top of price. One sleeve. If it hesitates, scratch it.",
		decimals: 4,
		sizeLabel: "SUI",
		dollarsPerUnit: 1,
		notionalPerUnit: 2.184
	},
	{
		id: "bonk-short",
		domain: "degen",
		symbol: "BONK",
		market: "Perp",
		direction: "short",
		entry: 2184e-8,
		tp: 2156e-8,
		sl: 2195e-8,
		confidence: 57,
		timeframe: "5m",
		session: "UTC",
		thesis: "Offer is sitting on the local high. Not live until the ask gets hit and holds. Easy to skip.",
		decimals: 8,
		sizeLabel: "BONK",
		dollarsPerUnit: 1,
		notionalPerUnit: 2184e-8
	},
	{
		id: "tia-short",
		domain: "degen",
		symbol: "TIA",
		market: "Perp",
		direction: "short",
		entry: 6.84,
		tp: 6.62,
		sl: 6.94,
		confidence: 55,
		timeframe: "15m",
		session: "UTC",
		thesis: "Fade failed. Price ran the stop. The call is dead — no re-entry on the same high.",
		decimals: 2,
		sizeLabel: "TIA",
		dollarsPerUnit: 1,
		notionalPerUnit: 6.84
	}
];
var META = {
	"btc-usd": {
		status: "live",
		ageMin: 18,
		trigger: "Shelf hold"
	},
	"eth-usd": {
		status: "live",
		ageMin: 22,
		trigger: "Measured bid"
	},
	"sol-usd": {
		status: "live",
		ageMin: 11,
		trigger: "Failed high"
	},
	"eurusd-long": {
		status: "live",
		ageMin: 22,
		trigger: "Shelf bid"
	},
	"gbpusd-short": {
		status: "live",
		ageMin: 41,
		trigger: "London fail"
	},
	"usdjpy-long": {
		status: "live",
		ageMin: 55,
		trigger: "Demand hold"
	},
	"xauusd-long": {
		status: "watching",
		ageMin: 80,
		trigger: "Retest hold"
	},
	"audusd-short": {
		status: "live",
		ageMin: 18,
		trigger: "Session roll"
	},
	"usdcad-long": {
		status: "watching",
		ageMin: 95,
		trigger: "Asia base"
	},
	"nzdusd-long": {
		status: "tp",
		ageMin: 240,
		trigger: "Measured move"
	},
	"sol-long": {
		status: "live",
		ageMin: 6,
		trigger: "Range break"
	},
	"wif-long": {
		status: "live",
		ageMin: 4,
		trigger: "Hot funding"
	},
	"pepe-long": {
		status: "watching",
		ageMin: 11,
		trigger: "Impulse"
	},
	"doge-short": {
		status: "live",
		ageMin: 8,
		trigger: "Supply fade"
	},
	"sui-long": {
		status: "live",
		ageMin: 3,
		trigger: "Sleeve break"
	},
	"bonk-short": {
		status: "watching",
		ageMin: 15,
		trigger: "Local offer"
	},
	"tia-short": {
		status: "stop",
		ageMin: 50,
		trigger: "Failed fade"
	}
};
var SIGNALS = CORE.map((row) => {
	const meta = META[row.id];
	if (!meta) throw new Error(`Missing signal meta for ${row.id}`);
	return {
		...row,
		...meta
	};
});
var STATUS_RANK = {
	live: 0,
	watching: 1,
	tp: 2,
	stop: 3
};
function rankSignals(list) {
	return [...list].sort((a, b) => STATUS_RANK[a.status] - STATUS_RANK[b.status] || b.confidence - a.confidence);
}
var activeBook = SIGNALS;
function installBook(rows) {
	activeBook = rows;
}
function signalsFor(domain) {
	return activeBook.filter((s) => s.domain === domain);
}
function getSignal(id) {
	if (!id) return void 0;
	return activeBook.find((s) => s.id === id);
}
function rewardRisk(signal) {
	const risk = Math.abs(signal.entry - signal.sl);
	const reward = Math.abs(signal.tp - signal.entry);
	if (risk === 0) return 0;
	return reward / risk;
}
function riskCash(equity, riskPct) {
	return equity * (riskPct / 100);
}
function unitSize(signal, equity, riskPct) {
	const stop = Math.abs(signal.entry - signal.sl);
	if (stop === 0 || signal.dollarsPerUnit === 0) return 0;
	return riskCash(equity, riskPct) / (stop * signal.dollarsPerUnit);
}
function notionalUsd(signal, units) {
	return units * signal.notionalPerUnit;
}
function impliedLeverage(notional, equity) {
	if (equity <= 0) return 0;
	return notional / equity;
}
function formatRr(rr) {
	return `${rr.toFixed(2)} : 1`;
}
function formatPct(n) {
	return `${n.toFixed(2)}%`;
}
function formatUsd(n) {
	return n.toLocaleString("en-US", {
		style: "currency",
		currency: "USD",
		maximumFractionDigits: n >= 1e3 ? 0 : 2
	});
}
function formatUnits(n) {
	const abs = Math.abs(n);
	if (abs >= 1e9) return `${(n / 1e9).toFixed(2)}B`;
	if (abs >= 1e6) return `${(n / 1e6).toFixed(2)}M`;
	if (abs >= 1e4) return `${(n / 1e3).toFixed(1)}k`;
	if (abs >= 100) return n.toFixed(0);
	if (abs >= 10) return n.toFixed(1);
	return n.toFixed(2);
}
var ALIAS = {
	BTC: "BTC/USD",
	BTCUSD: "BTC/USD",
	"BTC/USD": "BTC/USD",
	ETH: "ETH/USD",
	ETHUSD: "ETH/USD",
	"ETH/USD": "ETH/USD",
	SOL: "SOL/USD",
	SOLUSD: "SOL/USD",
	"SOL/USD": "SOL/USD",
	EURUSD: "EUR/USD",
	"EUR/USD": "EUR/USD",
	GBPUSD: "GBP/USD",
	"GBP/USD": "GBP/USD",
	USDJPY: "USD/JPY",
	"USD/JPY": "USD/JPY",
	AUDUSD: "AUD/USD",
	"AUD/USD": "AUD/USD",
	USDCAD: "USD/CAD",
	"USD/CAD": "USD/CAD",
	NZDUSD: "NZD/USD",
	"NZD/USD": "NZD/USD",
	XAUUSD: "XAU/USD",
	"XAU/USD": "XAU/USD"
};
function quoteSymbol(symbol) {
	return ALIAS[symbol.toUpperCase().replace(/\s/g, "")] ?? null;
}
function formatQuote(price, symbol) {
	if (symbol.includes("JPY")) return price.toFixed(3);
	if (price >= 1e3) return price.toLocaleString("en-US", { maximumFractionDigits: 2 });
	if (price >= 10) return price.toFixed(2);
	return price.toFixed(5);
}
//#endregion
export { signalsFor as _, formatQuote as a, formatUsd as c, installBook as d, notionalUsd as f, riskCash as g, rewardRisk as h, formatPct as i, getSignal as l, rankSignals as m, SIGNALS as n, formatRr as o, quoteSymbol as p, authMiddleware as r, formatUnits as s, DOMAINS as t, impliedLeverage as u, unitSize as v };
