import { x as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { r as signIn } from "./client-IWHfIGH2.mjs";
import { t as GROK_PROVIDERS } from "./server-B6PdCtAo.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/login-DEY3_mdf.js
var import_jsx_runtime = require_jsx_runtime();
function Login() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
		className: "grid min-h-screen place-items-center p-6",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "panel w-full max-w-sm space-y-3 p-6",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "pill",
					children: "ACCOUNT"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "h-display text-[1.6rem]",
					children: "SIGN IN"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "lede",
					children: "Your dashboard keeps the signals you take, and the tape marks them win or loss."
				}),
				GROK_PROVIDERS.map((provider) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "lock",
					onClick: () => signIn(provider.providerId, { callbackURL: "/" }),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "lock-copy",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("strong", { children: ["CONTINUE WITH ", provider.label.toUpperCase()] })
					})
				}, provider.providerId))
			]
		})
	});
}
//#endregion
export { Login as component };
