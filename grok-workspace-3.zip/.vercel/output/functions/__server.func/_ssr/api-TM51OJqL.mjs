import { i as TSS_SERVER_FUNCTION, r as createServerFn } from "./ssr.mjs";
import { n as SIGNALS, p as quoteSymbol, r as authMiddleware } from "./quotes-yP9O0pTE.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/api-TM51OJqL.js
var createServerRpc = (serverFnMeta, splitImportFn) => {
	const url = "/_serverFn/" + serverFnMeta.id;
	return Object.assign(splitImportFn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var FUTURES = [
	"BTC/USD",
	"ETH/USD",
	"SOL/USD"
];
function num(value) {
	const n = typeof value === "number" ? value : Number(value);
	return Number.isFinite(n) ? n : 0;
}
function toSignal(row) {
	return {
		id: row.id,
		domain: row.domain,
		symbol: row.symbol,
		market: row.market,
		direction: row.direction,
		entry: num(row.entry),
		tp: num(row.tp),
		sl: num(row.sl),
		confidence: num(row.confidence),
		timeframe: row.timeframe,
		session: row.session,
		thesis: row.thesis,
		decimals: num(row.decimals),
		sizeLabel: row.size_label,
		dollarsPerUnit: num(row.dollars_per_unit),
		notionalPerUnit: num(row.notional_per_unit),
		status: row.status,
		ageMin: num(row.age_min),
		trigger: row.trigger
	};
}
async function db() {
	const { getSql } = await import("./db-9-z4ryYn.mjs").then((n) => n.t).then((n) => n.t);
	return getSql();
}
async function ensureSeed(sql) {
	if (num((await sql`select count(*)::int as n from signals`)[0]?.n) > 0) return;
	for (const row of SIGNALS) await sql`
      insert into signals (
        id, domain, symbol, market, direction, entry, tp, sl, confidence, timeframe, session,
        thesis, decimals, size_label, dollars_per_unit, notional_per_unit, status, age_min, trigger
      ) values (
        ${row.id}, ${row.domain}, ${row.symbol}, ${row.market}, ${row.direction}, ${row.entry},
        ${row.tp}, ${row.sl}, ${row.confidence}, ${row.timeframe}, ${row.session}, ${row.thesis},
        ${row.decimals}, ${row.sizeLabel}, ${row.dollarsPerUnit}, ${row.notionalPerUnit},
        ${row.status}, ${row.ageMin}, ${row.trigger}
      )
    `;
}
function specFor(domain, symbol, entry) {
	const hit = {
		"BTC/USD": {
			decimals: 2,
			dollarsPerUnit: 1,
			sizeLabel: "BTC",
			market: "Futures",
			notional: entry
		},
		"ETH/USD": {
			decimals: 2,
			dollarsPerUnit: 1,
			sizeLabel: "ETH",
			market: "Futures",
			notional: entry
		},
		"SOL/USD": {
			decimals: 2,
			dollarsPerUnit: 1,
			sizeLabel: "SOL",
			market: "Futures",
			notional: entry
		},
		EURUSD: {
			decimals: 5,
			dollarsPerUnit: 1e5,
			sizeLabel: "lots",
			market: "Forex",
			notional: 1e5 * entry
		},
		GBPUSD: {
			decimals: 5,
			dollarsPerUnit: 1e5,
			sizeLabel: "lots",
			market: "Forex",
			notional: 1e5 * entry
		},
		AUDUSD: {
			decimals: 5,
			dollarsPerUnit: 1e5,
			sizeLabel: "lots",
			market: "Forex",
			notional: 1e5 * entry
		},
		NZDUSD: {
			decimals: 5,
			dollarsPerUnit: 1e5,
			sizeLabel: "lots",
			market: "Forex",
			notional: 1e5 * entry
		},
		USDJPY: {
			decimals: 3,
			dollarsPerUnit: 1e5 / Math.max(entry, 1),
			sizeLabel: "lots",
			market: "Forex",
			notional: 1e5
		},
		USDCAD: {
			decimals: 5,
			dollarsPerUnit: 1e5,
			sizeLabel: "lots",
			market: "Forex",
			notional: 1e5
		},
		XAUUSD: {
			decimals: 2,
			dollarsPerUnit: 1,
			sizeLabel: "oz",
			market: "Forex",
			notional: entry
		}
	}[symbol];
	if (hit) return hit;
	if (domain === "futures") throw new Error("Futures signals are only BTC/USD, ETH/USD, and SOL/USD.");
	return {
		decimals: entry >= 100 ? 2 : entry >= 1 ? 4 : 8,
		dollarsPerUnit: 1,
		sizeLabel: symbol,
		market: domain === "forex" ? "Forex" : "Perp",
		notional: entry
	};
}
function parseDraft(input) {
	if (!input || typeof input !== "object") throw new Error("Missing signal");
	const row = input;
	const domain = row.domain;
	const direction = row.direction;
	const status = row.status;
	if (domain !== "futures" && domain !== "forex" && domain !== "degen") throw new Error("Pick a domain");
	if (direction !== "long" && direction !== "short") throw new Error("Pick a direction");
	if (status !== "live" && status !== "watching" && status !== "tp" && status !== "stop") throw new Error("Pick a status");
	const symbol = String(row.symbol ?? "").trim().toUpperCase().replace(/\s/g, "");
	if (!symbol) throw new Error("Symbol is required");
	if (domain === "futures" && !FUTURES.includes(symbol)) throw new Error("Futures signals are only BTC/USD, ETH/USD, and SOL/USD.");
	const entry = num(row.entry);
	const tp = num(row.tp);
	const sl = num(row.sl);
	const confidence = Math.round(num(row.confidence));
	if (entry <= 0 || tp <= 0 || sl <= 0) throw new Error("Entry, target, and stop must be prices");
	if (Math.abs(entry - sl) === 0) throw new Error("Stop cannot sit on the entry");
	if (confidence < 1 || confidence > 99) throw new Error("Confidence is 1 to 99");
	const thesis = String(row.thesis ?? "").trim();
	if (thesis.length < 8) throw new Error("Add a short note so the desk knows why");
	const timeframe = String(row.timeframe ?? "1H").trim() || "1H";
	return {
		id: typeof row.id === "string" && row.id ? row.id : void 0,
		domain,
		symbol,
		direction,
		entry,
		tp,
		sl,
		confidence,
		timeframe,
		thesis,
		status
	};
}
async function isAdmin(sql, userId) {
	return (await sql`select user_id from admins where user_id = ${userId}`).length > 0;
}
var cachedQuotes = [];
var cachedAt = 0;
var sessionOpen = /* @__PURE__ */ new Map();
function stamp(rows) {
	return rows.map((row) => {
		if (row.changePct != null) return row;
		const open = sessionOpen.get(row.symbol);
		if (open == null) {
			sessionOpen.set(row.symbol, row.price);
			return {
				...row,
				changePct: 0
			};
		}
		return {
			...row,
			changePct: (row.price - open) / open * 100
		};
	});
}
async function krakenCrypto() {
	const res = await fetch("https://api.kraken.com/0/public/Ticker?pair=XBTUSD,ETHUSD,SOLUSD", { signal: AbortSignal.timeout(6e3) });
	if (!res.ok) throw new Error("crypto feed down");
	const result = (await res.json()).result ?? {};
	const want = [
		{
			symbol: "BTC/USD",
			test: (key) => key.includes("XBT")
		},
		{
			symbol: "ETH/USD",
			test: (key) => key.includes("ETH")
		},
		{
			symbol: "SOL/USD",
			test: (key) => key.includes("SOL")
		}
	];
	const out = [];
	for (const item of want) {
		const key = Object.keys(result).find(item.test);
		if (!key) continue;
		const last = num(result[key]?.c?.[0]);
		const open = num(result[key]?.o);
		if (last <= 0) continue;
		out.push({
			symbol: item.symbol,
			price: last,
			changePct: open > 0 ? (last - open) / open * 100 : null,
			kind: "crypto"
		});
	}
	return out;
}
async function coinbaseSpot(pair, symbol) {
	const res = await fetch(`https://api.coinbase.com/v2/prices/${pair}/spot`, { signal: AbortSignal.timeout(6e3) });
	if (!res.ok) return null;
	const price = num((await res.json()).data?.amount);
	if (price <= 0) return null;
	return {
		symbol,
		price,
		changePct: null,
		kind: "crypto"
	};
}
async function cryptoQuotes() {
	try {
		const rows = await krakenCrypto();
		if (rows.length >= 3) return rows;
	} catch {}
	return (await Promise.all([
		["BTC-USD", "BTC/USD"],
		["ETH-USD", "ETH/USD"],
		["SOL-USD", "SOL/USD"]
	].map(([pair, symbol]) => coinbaseSpot(pair, symbol)))).filter((row) => row != null);
}
async function forexQuotes() {
	const res = await fetch("https://api.frankfurter.dev/v1/latest?from=USD&to=EUR,GBP,JPY,AUD,CAD,NZD", { signal: AbortSignal.timeout(6e3) });
	if (!res.ok) return [];
	const rates = (await res.json()).rates ?? {};
	const out = [];
	const push = (symbol, price) => {
		if (price > 0) out.push({
			symbol,
			price,
			changePct: null,
			kind: "forex"
		});
	};
	if (rates.EUR) push("EUR/USD", 1 / rates.EUR);
	if (rates.GBP) push("GBP/USD", 1 / rates.GBP);
	if (rates.JPY) push("USD/JPY", rates.JPY);
	if (rates.AUD) push("AUD/USD", 1 / rates.AUD);
	if (rates.CAD) push("USD/CAD", rates.CAD);
	if (rates.NZD) push("NZD/USD", 1 / rates.NZD);
	return out;
}
async function loadQuotes() {
	if (Date.now() - cachedAt < 5e3 && cachedQuotes.length > 0) return cachedQuotes;
	const [crypto, forex] = await Promise.allSettled([cryptoQuotes(), forexQuotes()]);
	const rows = [...crypto.status === "fulfilled" ? crypto.value : [], ...forex.status === "fulfilled" ? forex.value : []];
	if (rows.length > 0) {
		cachedQuotes = stamp(rows);
		cachedAt = Date.now();
	}
	return cachedQuotes;
}
function markOf(symbol, quotes) {
	const key = quoteSymbol(symbol);
	if (!key) return null;
	return quotes.find((quote) => quote.symbol === key)?.price ?? null;
}
function unitsOf(entry, sl, equity, riskPct, dollarsPerUnit) {
	const stop = Math.abs(entry - sl);
	if (stop === 0 || dollarsPerUnit === 0) return 0;
	return equity * (riskPct / 100) / (stop * dollarsPerUnit);
}
function pnlOf(direction, entry, exit, units, dollarsPerUnit) {
	return (direction === "long" ? exit - entry : entry - exit) * dollarsPerUnit * units;
}
function present(row, mark) {
	const entry = num(row.entry);
	const tp = num(row.tp);
	const sl = num(row.sl);
	const dollars = num(row.dollars_per_unit);
	const units = unitsOf(entry, sl, num(row.equity), num(row.risk_pct), dollars);
	const outcome = row.outcome === "win" || row.outcome === "loss" ? row.outcome : null;
	const exitPrice = row.exit_price == null ? null : num(row.exit_price);
	const pnl = outcome && exitPrice != null ? pnlOf(row.direction, entry, exitPrice, units, dollars) : mark != null ? pnlOf(row.direction, entry, mark, units, dollars) : 0;
	return {
		id: row.id,
		signalId: row.signal_id,
		symbol: row.symbol,
		domain: row.domain,
		direction: row.direction,
		entry,
		tp,
		sl,
		decimals: num(row.decimals),
		riskPct: num(row.risk_pct),
		equity: num(row.equity),
		takenAt: new Date(row.taken_at).toISOString(),
		outcome,
		exitPrice,
		pnlUsd: pnl,
		mark
	};
}
var getQuotes_createServerFn_handler = createServerRpc({
	id: "1d923333db590d8d1676a616594b7e7f0aaca77bee9fecb54d6d701283183471",
	name: "getQuotes",
	filename: "src/lib/tradfi/api.ts"
}, (opts) => getQuotes.__executeServer(opts));
var getQuotes = createServerFn({ method: "GET" }).handler(getQuotes_createServerFn_handler, async () => loadQuotes());
var listSignals_createServerFn_handler = createServerRpc({
	id: "8834fe0cefb2ed0545e9df53ebe53f41e16aa0124e70a46fa5e2ca20bb6a2fae",
	name: "listSignals",
	filename: "src/lib/tradfi/api.ts"
}, (opts) => listSignals.__executeServer(opts));
var listSignals = createServerFn({ method: "GET" }).handler(listSignals_createServerFn_handler, async () => {
	const sql = await db();
	await ensureSeed(sql);
	return (await sql`
    select id, domain, symbol, market, direction, entry, tp, sl, confidence, timeframe, session,
           thesis, decimals, size_label, dollars_per_unit, notional_per_unit, status, age_min, trigger
    from signals
    where active = true
    order by updated_at desc
  `).map(toSignal);
});
var deskAccess_createServerFn_handler = createServerRpc({
	id: "1ecac40176ba72ad7330ccedcb3342959a2781cd2173ae081ecea90932061c33",
	name: "deskAccess",
	filename: "src/lib/tradfi/api.ts"
}, (opts) => deskAccess.__executeServer(opts));
var deskAccess = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(deskAccess_createServerFn_handler, async ({ context }) => {
	const sql = await db();
	return {
		admin: await isAdmin(sql, context.userId),
		openSeat: num((await sql`select count(*)::int as n from admins`)[0]?.n) === 0
	};
});
var claimAdmin_createServerFn_handler = createServerRpc({
	id: "383fe9c690c8a27d92c1c4f36047b1023a0c8ccc6921334a1f37897c35575e36",
	name: "claimAdmin",
	filename: "src/lib/tradfi/api.ts"
}, (opts) => claimAdmin.__executeServer(opts));
var claimAdmin = createServerFn({ method: "POST" }).middleware([authMiddleware]).handler(claimAdmin_createServerFn_handler, async ({ context }) => {
	const sql = await db();
	if (num((await sql`select count(*)::int as n from admins`)[0]?.n) > 0) {
		if (!await isAdmin(sql, context.userId)) throw new Error("This desk already has an operator");
		return { admin: true };
	}
	await sql`insert into admins (user_id) values (${context.userId})`;
	return { admin: true };
});
var saveSignal_createServerFn_handler = createServerRpc({
	id: "f362adb74d3a0f1ad5e41e356b11c02986bdbb681404d849e89a9999ef4d24ce",
	name: "saveSignal",
	filename: "src/lib/tradfi/api.ts"
}, (opts) => saveSignal.__executeServer(opts));
var saveSignal = createServerFn({ method: "POST" }).validator(parseDraft).middleware([authMiddleware]).handler(saveSignal_createServerFn_handler, async ({ context, data }) => {
	const sql = await db();
	if (!await isAdmin(sql, context.userId)) throw new Error("Only the operator can post signals");
	const spec = specFor(data.domain, data.symbol, data.entry);
	const id = data.id ?? `${data.domain}-${data.symbol.toLowerCase().replace(/[^a-z0-9]+/g, "")}-${Date.now().toString(36)}`;
	await sql`
      insert into signals (
        id, domain, symbol, market, direction, entry, tp, sl, confidence, timeframe, session,
        thesis, decimals, size_label, dollars_per_unit, notional_per_unit, status, age_min, trigger, active, updated_at
      ) values (
        ${id}, ${data.domain}, ${data.symbol}, ${spec.market}, ${data.direction}, ${data.entry}, ${data.tp},
        ${data.sl}, ${data.confidence}, ${data.timeframe}, ${"UTC"}, ${data.thesis}, ${spec.decimals},
        ${spec.sizeLabel}, ${spec.dollarsPerUnit}, ${spec.notional}, ${data.status}, ${0}, ${"Manual"}, true, now()
      )
      on conflict (id) do update set
        domain = excluded.domain,
        symbol = excluded.symbol,
        market = excluded.market,
        direction = excluded.direction,
        entry = excluded.entry,
        tp = excluded.tp,
        sl = excluded.sl,
        confidence = excluded.confidence,
        timeframe = excluded.timeframe,
        thesis = excluded.thesis,
        decimals = excluded.decimals,
        size_label = excluded.size_label,
        dollars_per_unit = excluded.dollars_per_unit,
        notional_per_unit = excluded.notional_per_unit,
        status = excluded.status,
        active = true,
        updated_at = now()
    `;
	return { id };
});
var retireSignal_createServerFn_handler = createServerRpc({
	id: "ac3bef35eeccf41f7c696628073b5a5c3c88323927666c46e7c8a261898a3b3a",
	name: "retireSignal",
	filename: "src/lib/tradfi/api.ts"
}, (opts) => retireSignal.__executeServer(opts));
var retireSignal = createServerFn({ method: "POST" }).validator((id) => {
	if (!id) throw new Error("Missing signal");
	return id;
}).middleware([authMiddleware]).handler(retireSignal_createServerFn_handler, async ({ context, data: id }) => {
	const sql = await db();
	if (!await isAdmin(sql, context.userId)) throw new Error("Only the operator can pull a signal");
	await sql`update signals set active = false, updated_at = now() where id = ${id}`;
	return { id };
});
var takeSignal_createServerFn_handler = createServerRpc({
	id: "7b3e069b18d7052ff685552b44c1ae792791eafdbdb8aa343c71fc21bba59197",
	name: "takeSignal",
	filename: "src/lib/tradfi/api.ts"
}, (opts) => takeSignal.__executeServer(opts));
var takeSignal = createServerFn({ method: "POST" }).validator((input) => {
	if (!input?.signalId) throw new Error("Missing signal");
	const riskPct = num(input.riskPct);
	const equity = num(input.equity);
	if (riskPct <= 0 || equity <= 0) throw new Error("Set equity and risk before you take it");
	return {
		signalId: input.signalId,
		riskPct,
		equity
	};
}).middleware([authMiddleware]).handler(takeSignal_createServerFn_handler, async ({ context, data }) => {
	const sql = await db();
	const signal = (await sql`
      select id, domain, symbol, market, direction, entry, tp, sl, confidence, timeframe, session,
             thesis, decimals, size_label, dollars_per_unit, notional_per_unit, status, age_min, trigger
      from signals where id = ${data.signalId} and active = true
    `)[0];
	if (!signal) throw new Error("That signal is no longer on the desk");
	if (signal.status === "tp" || signal.status === "stop") throw new Error("That call is already closed");
	const open = await sql`
      select id from takes where user_id = ${context.userId} and signal_id = ${signal.id} and outcome is null
    `;
	if (open.length > 0) return { id: open[0].id };
	const id = crypto.randomUUID();
	await sql`
      insert into takes (
        id, user_id, signal_id, symbol, domain, direction, entry, tp, sl, decimals,
        risk_pct, equity, dollars_per_unit, size_label
      ) values (
        ${id}, ${context.userId}, ${signal.id}, ${signal.symbol}, ${signal.domain}, ${signal.direction},
        ${num(signal.entry)}, ${num(signal.tp)}, ${num(signal.sl)}, ${num(signal.decimals)},
        ${data.riskPct}, ${data.equity}, ${num(signal.dollars_per_unit)}, ${signal.size_label}
      )
    `;
	return { id };
});
var releaseTake_createServerFn_handler = createServerRpc({
	id: "8f99a72d1b4d49f06d3cf4ac26ca26136d429636e042fba2763821a9fd949aaa",
	name: "releaseTake",
	filename: "src/lib/tradfi/api.ts"
}, (opts) => releaseTake.__executeServer(opts));
var releaseTake = createServerFn({ method: "POST" }).validator((id) => {
	if (!id) throw new Error("Missing take");
	return id;
}).middleware([authMiddleware]).handler(releaseTake_createServerFn_handler, async ({ context, data: id }) => {
	await (await db())`delete from takes where id = ${id} and user_id = ${context.userId} and outcome is null`;
	return { id };
});
var myDashboard_createServerFn_handler = createServerRpc({
	id: "7263f49db86c5a52473152f9d2734f116c46334987559ea1a8972e4ab509de9b",
	name: "myDashboard",
	filename: "src/lib/tradfi/api.ts"
}, (opts) => myDashboard.__executeServer(opts));
var myDashboard = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(myDashboard_createServerFn_handler, async ({ context }) => {
	const sql = await db();
	const quotes = await loadQuotes();
	const rows = await sql`
      select id, signal_id, symbol, domain, direction, entry, tp, sl, decimals, risk_pct, equity,
             dollars_per_unit, taken_at, outcome, exit_price, pnl_usd
      from takes
      where user_id = ${context.userId}
      order by taken_at desc
    `;
	for (const row of rows) {
		if (row.outcome === "win" || row.outcome === "loss") continue;
		const mark = markOf(row.symbol, quotes);
		if (mark == null) continue;
		const entry = num(row.entry);
		const tp = num(row.tp);
		const sl = num(row.sl);
		const hitTp = row.direction === "long" ? mark >= tp : mark <= tp;
		const hitSl = row.direction === "long" ? mark <= sl : mark >= sl;
		if (!hitTp && !hitSl) continue;
		const outcome = hitTp ? "win" : "loss";
		const exitPrice = hitTp ? tp : sl;
		const dollars = num(row.dollars_per_unit);
		const units = unitsOf(entry, sl, num(row.equity), num(row.risk_pct), dollars);
		const pnl = pnlOf(row.direction, entry, exitPrice, units, dollars);
		await sql`
        update takes
        set outcome = ${outcome}, exit_price = ${exitPrice}, pnl_usd = ${pnl}, closed_at = now()
        where id = ${row.id} and user_id = ${context.userId} and outcome is null
      `;
		row.outcome = outcome;
		row.exit_price = exitPrice;
		row.pnl_usd = pnl;
	}
	const views = rows.map((row) => present(row, row.outcome ? null : markOf(row.symbol, quotes)));
	const wins = views.filter((row) => row.outcome === "win").length;
	const losses = views.filter((row) => row.outcome === "loss").length;
	const closed = wins + losses;
	return {
		taken: views.length,
		open: views.filter((row) => row.outcome == null).length,
		wins,
		losses,
		winRate: closed === 0 ? 0 : wins / closed * 100,
		netPnl: views.reduce((sum, row) => sum + row.pnlUsd, 0),
		rows: views
	};
});
//#endregion
export { claimAdmin_createServerFn_handler, deskAccess_createServerFn_handler, getQuotes_createServerFn_handler, listSignals_createServerFn_handler, myDashboard_createServerFn_handler, releaseTake_createServerFn_handler, retireSignal_createServerFn_handler, saveSignal_createServerFn_handler, takeSignal_createServerFn_handler };
