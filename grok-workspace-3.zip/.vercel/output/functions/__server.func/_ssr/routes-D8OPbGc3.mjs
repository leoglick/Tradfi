import { o as __toESM } from "../_runtime.mjs";
import { J as require_react, x as require_jsx_runtime, y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as getServerFnById, i as TSS_SERVER_FUNCTION, r as createServerFn } from "./ssr.mjs";
import { _ as signalsFor, a as formatQuote, c as formatUsd, d as installBook, f as notionalUsd, g as riskCash, h as rewardRisk, i as formatPct, l as getSignal, m as rankSignals, o as formatRr, r as authMiddleware, s as formatUnits, t as DOMAINS, u as impliedLeverage, v as unitSize } from "./quotes-yP9O0pTE.mjs";
import { i as signOut, t as authClient } from "./client-IWHfIGH2.mjs";
import { a as hasGateSessionMarker } from "./server-B6PdCtAo.mjs";
import { n as ShieldCheck } from "../_libs/lucide-react.mjs";
import { n as persist, r as create, t as createJSONStorage } from "../_libs/zustand.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-D8OPbGc3.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
/**
* Current user + loading state. Same behavior in live preview and when deployed:
*   - Auth enabled -> the real signed-in user; `user` is `null` while
*                            the session resolves (`isPending: true`) and when
*                            signed out (`isPending: false`). Session comes from
*                            Better Auth `useSession()` → `/api/auth/get-session`
*                            (cookie when deployed; bearer in live preview).
*   - Auth disabled (`VITE_AUTH_ENABLED=false`) -> `DEV_USER`, never pending.
*
* Protect a route by waiting out `isPending` before acting on `user` —
* redirecting on `user: null` alone bounces signed-in visitors to sign-in on
* every hard reload:
*
*   import { RedirectToSignIn } from "@/lib/auth/gates";
*   const { user, isPending } = useCurrentUserState();
*   if (isPending) return null;              // still resolving — don't redirect yet
*   if (!user) return <RedirectToSignIn />;  // definitely signed out
*
* `authEnabled` is a module-level constant fixed at load, so the guarded hook
* call keeps a stable hook order across every render of a given component.
*/
function useCurrentUserState() {
	const { data, isPending } = authClient.useSession();
	const user = data?.user;
	return {
		user: user ? {
			id: user.id,
			displayName: user.name ?? null,
			primaryEmail: user.email ?? null,
			profileImageUrl: user.image ?? null,
			isDevFallback: false
		} : null,
		isPending
	};
}
/**
* Convenience view of `useCurrentUserState().user` for display (e.g.
* `user?.displayName ?? "Guest"`). NOTE: `null` means *loading OR signed out* —
* for redirects/guards use `useCurrentUserState()` and check `isPending`.
*/
function useCurrentUser() {
	return useCurrentUserState().user;
}
var subscribeToNothing = () => () => {};
var noGateSessionOnServer = () => false;
/**
* Minimal signed-in identity chip + sign-out. Restyle freely (see the
* `design-ui` skill). Sign-out is only shown when auth is enabled (the
* disabled-auth dev user has nothing to sign out of) and the session is not
* gate-materialized — behind the gate the next request signs the viewer
* straight back in, so a sign-out control there is a broken loop.
*/
function UserButton() {
	const user = useCurrentUser();
	const [signingOut, setSigningOut] = (0, import_react.useState)(false);
	const gateSession = (0, import_react.useSyncExternalStore)(subscribeToNothing, hasGateSessionMarker, noGateSessionOnServer);
	if (!user) return null;
	const label = user.displayName ?? user.primaryEmail ?? "Account";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-center gap-2",
		children: [
			user.profileImageUrl ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: user.profileImageUrl,
				alt: "",
				className: "h-8 w-8 rounded-full object-cover"
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "grid h-8 w-8 place-items-center rounded-full bg-black/10 text-sm font-medium dark:bg-white/20",
				children: label.charAt(0).toUpperCase()
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-sm font-medium",
				children: label
			}),
			!gateSession && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				disabled: signingOut,
				onClick: () => {
					setSigningOut(true);
					signOut().catch(() => setSigningOut(false));
				},
				className: "cursor-pointer text-sm underline-offset-4 opacity-70 hover:underline disabled:cursor-wait disabled:no-underline",
				children: signingOut ? "Signing out…" : "Sign out"
			})
		]
	});
}
var createSsrRpc = (functionId) => {
	const url = "/_serverFn/" + functionId;
	const serverFnMeta = { id: functionId };
	const fn = async (...args) => {
		return (await getServerFnById(functionId, { origin: "server" }))(...args);
	};
	return Object.assign(fn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var FUTURES$1 = [
	"BTC/USD",
	"ETH/USD",
	"SOL/USD"
];
function num(value) {
	const n = typeof value === "number" ? value : Number(value);
	return Number.isFinite(n) ? n : 0;
}
function parseDraft(input) {
	if (!input || typeof input !== "object") throw new Error("Missing signal");
	const row = input;
	const domain = row.domain;
	const direction = row.direction;
	const status = row.status;
	if (domain !== "futures" && domain !== "forex" && domain !== "degen") throw new Error("Pick a domain");
	if (direction !== "long" && direction !== "short") throw new Error("Pick a direction");
	if (status !== "live" && status !== "watching" && status !== "tp" && status !== "stop") throw new Error("Pick a status");
	const symbol = String(row.symbol ?? "").trim().toUpperCase().replace(/\s/g, "");
	if (!symbol) throw new Error("Symbol is required");
	if (domain === "futures" && !FUTURES$1.includes(symbol)) throw new Error("Futures signals are only BTC/USD, ETH/USD, and SOL/USD.");
	const entry = num(row.entry);
	const tp = num(row.tp);
	const sl = num(row.sl);
	const confidence = Math.round(num(row.confidence));
	if (entry <= 0 || tp <= 0 || sl <= 0) throw new Error("Entry, target, and stop must be prices");
	if (Math.abs(entry - sl) === 0) throw new Error("Stop cannot sit on the entry");
	if (confidence < 1 || confidence > 99) throw new Error("Confidence is 1 to 99");
	const thesis = String(row.thesis ?? "").trim();
	if (thesis.length < 8) throw new Error("Add a short note so the desk knows why");
	const timeframe = String(row.timeframe ?? "1H").trim() || "1H";
	return {
		id: typeof row.id === "string" && row.id ? row.id : void 0,
		domain,
		symbol,
		direction,
		entry,
		tp,
		sl,
		confidence,
		timeframe,
		thesis,
		status
	};
}
var getQuotes = createServerFn({ method: "GET" }).handler(createSsrRpc("1d923333db590d8d1676a616594b7e7f0aaca77bee9fecb54d6d701283183471"));
var listSignals = createServerFn({ method: "GET" }).handler(createSsrRpc("8834fe0cefb2ed0545e9df53ebe53f41e16aa0124e70a46fa5e2ca20bb6a2fae"));
var deskAccess = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(createSsrRpc("1ecac40176ba72ad7330ccedcb3342959a2781cd2173ae081ecea90932061c33"));
var claimAdmin = createServerFn({ method: "POST" }).middleware([authMiddleware]).handler(createSsrRpc("383fe9c690c8a27d92c1c4f36047b1023a0c8ccc6921334a1f37897c35575e36"));
var saveSignal = createServerFn({ method: "POST" }).validator(parseDraft).middleware([authMiddleware]).handler(createSsrRpc("f362adb74d3a0f1ad5e41e356b11c02986bdbb681404d849e89a9999ef4d24ce"));
var retireSignal = createServerFn({ method: "POST" }).validator((id) => {
	if (!id) throw new Error("Missing signal");
	return id;
}).middleware([authMiddleware]).handler(createSsrRpc("ac3bef35eeccf41f7c696628073b5a5c3c88323927666c46e7c8a261898a3b3a"));
var takeSignal = createServerFn({ method: "POST" }).validator((input) => {
	if (!input?.signalId) throw new Error("Missing signal");
	const riskPct = num(input.riskPct);
	const equity = num(input.equity);
	if (riskPct <= 0 || equity <= 0) throw new Error("Set equity and risk before you take it");
	return {
		signalId: input.signalId,
		riskPct,
		equity
	};
}).middleware([authMiddleware]).handler(createSsrRpc("7b3e069b18d7052ff685552b44c1ae792791eafdbdb8aa343c71fc21bba59197"));
var releaseTake = createServerFn({ method: "POST" }).validator((id) => {
	if (!id) throw new Error("Missing take");
	return id;
}).middleware([authMiddleware]).handler(createSsrRpc("8f99a72d1b4d49f06d3cf4ac26ca26136d429636e042fba2763821a9fd949aaa"));
var myDashboard = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(createSsrRpc("7263f49db86c5a52473152f9d2734f116c46334987559ea1a8972e4ab509de9b"));
var DEFAULT_CAPS = {
	futures: 2,
	forex: 1.5,
	degen: .5
};
var useDesk = create()(persist((set, get) => ({
	view: "brain",
	domain: null,
	signalId: null,
	equity: 25e3,
	riskPct: 1.25,
	dailyStopPct: 4,
	caps: DEFAULT_CAPS,
	locked: [],
	nudge: 0,
	bookRev: 0,
	setBook: (rows) => {
		installBook(rows);
		set((s) => ({ bookRev: s.bookRev + 1 }));
	},
	selectDomain: (domain) => set({ domain }),
	poke: () => set((s) => ({ nudge: s.nudge + 1 })),
	start: () => {
		const domain = get().domain ?? "futures";
		const first = rankSignals(signalsFor(domain))[0];
		set({
			domain,
			view: "setup",
			signalId: first?.id ?? null
		});
	},
	openSignal: (id) => {
		const signal = getSignal(id);
		if (!signal) return;
		set({
			view: "setup",
			domain: signal.domain,
			signalId: signal.id
		});
	},
	setRiskPct: (n) => set({ riskPct: clamp(n, .25, 3) }),
	setEquity: (n) => set({ equity: clamp(n, 100, 1e8) }),
	setDailyStop: (n) => set({ dailyStopPct: clamp(n, .5, 10) }),
	setCap: (domain, n) => set((s) => ({ caps: {
		...s.caps,
		[domain]: clamp(n, .25, 3)
	} })),
	lockCurrent: () => {
		const { signalId, riskPct, equity, caps, locked } = get();
		const signal = getSignal(signalId);
		if (!signal) return;
		if (signal.status === "tp" || signal.status === "stop") return;
		if (locked.some((row) => row.signalId === signal.id)) return;
		const applied = Math.min(riskPct, caps[signal.domain]);
		set({ locked: [{
			id: crypto.randomUUID(),
			signalId: signal.id,
			domain: signal.domain,
			symbol: signal.symbol,
			market: signal.market,
			direction: signal.direction,
			entry: signal.entry,
			tp: signal.tp,
			sl: signal.sl,
			decimals: signal.decimals,
			rr: rewardRisk(signal),
			confidence: signal.confidence,
			riskPct: applied,
			equity,
			timeframe: signal.timeframe,
			thesis: signal.thesis,
			lockedAt: Date.now()
		}, ...locked] });
	},
	removeLocked: (id) => set((s) => ({ locked: s.locked.filter((row) => row.id !== id) })),
	go: (view) => set({ view })
}), {
	name: "traderedge-desk",
	storage: createJSONStorage(() => localStorage),
	skipHydration: true,
	version: 1,
	partialize: (s) => ({
		equity: s.equity,
		riskPct: s.riskPct,
		dailyStopPct: s.dailyStopPct,
		caps: s.caps,
		locked: s.locked
	})
}));
function clamp(n, min, max) {
	if (Number.isNaN(n)) return min;
	return Math.min(max, Math.max(min, n));
}
function TopBar({ trailing }) {
	const go = useDesk((s) => s.go);
	const view = useDesk((s) => s.view);
	const { user, isPending } = useCurrentUserState();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
		className: "topbar",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "modes-btn",
				onClick: () => go("brain"),
				children: "Modes"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Watchlist, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
				className: "nav",
				"aria-label": "Desk",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: view === "dashboard" ? "nav-link is-active" : "nav-link",
						onClick: () => go("dashboard"),
						children: "Dashboard"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: view === "admin" ? "nav-link is-active" : "nav-link",
						onClick: () => go("admin"),
						children: "Admin"
					}),
					trailing,
					isPending ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "acct-skel" }) : user ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "account-slot",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserButton, {})
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/login",
						className: "nav-link",
						children: "Sign in"
					})
				]
			})
		]
	});
}
function Watchlist() {
	const [quotes, setQuotes] = (0, import_react.useState)([]);
	const [down, setDown] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		let stop = false;
		const load = () => {
			getQuotes().then((rows) => {
				if (stop) return;
				setQuotes(rows);
				setDown(rows.length === 0);
			}).catch(() => {
				if (!stop) setDown(true);
			});
		};
		load();
		const id = window.setInterval(load, 8e3);
		return () => {
			stop = true;
			window.clearInterval(id);
		};
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "watchlist",
		"aria-label": "Live watchlist",
		children: quotes.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "quote-wait",
			children: down ? "Feed delayed" : "Connecting tape…"
		}) : quotes.map((quote) => {
			const up = (quote.changePct ?? 0) >= 0;
			return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: "quote-chip",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "quote-sym",
					children: quote.symbol
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "quote-px",
					children: [formatQuote(quote.price, quote.symbol), quote.changePct == null ? null : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: up ? "quote-up" : "quote-dn",
						children: [
							" ",
							up ? "+" : "",
							quote.changePct.toFixed(2),
							"%"
						]
					})]
				})]
			}, quote.symbol);
		})
	});
}
function Foot() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("footer", {
		className: "foot",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "tagline",
				children: "LIVE TAPE. OPERATOR SIGNALS. YOUR P&L."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "foot-rule" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "disclaimer",
				children: "Coin and forex prices are live. Signals are posted by the desk operator. Not financial advice."
			})
		] })
	});
}
var FUTURES = [
	"BTC/USD",
	"ETH/USD",
	"SOL/USD"
];
var FOREX = [
	"EURUSD",
	"GBPUSD",
	"USDJPY",
	"AUDUSD",
	"USDCAD",
	"NZDUSD",
	"XAUUSD"
];
var BLANK = {
	domain: "futures",
	symbol: "BTC/USD",
	direction: "long",
	entry: 0,
	tp: 0,
	sl: 0,
	confidence: 70,
	timeframe: "1H",
	thesis: "",
	status: "live"
};
function AdminScreen() {
	const { user, isPending } = useCurrentUserState();
	const setBook = useDesk((s) => s.setBook);
	const [admin, setAdmin] = (0, import_react.useState)(false);
	const [openSeat, setOpenSeat] = (0, import_react.useState)(false);
	const [rows, setRows] = (0, import_react.useState)([]);
	const [draft, setDraft] = (0, import_react.useState)(BLANK);
	const [note, setNote] = (0, import_react.useState)("");
	async function refresh() {
		const next = await listSignals();
		setRows(next);
		setBook(next);
	}
	(0, import_react.useEffect)(() => {
		if (!user) return;
		let stop = false;
		const load = () => {
			deskAccess().then((access) => {
				if (stop) return;
				setAdmin(access.admin);
				setOpenSeat(access.openSeat);
			}).catch(() => void 0);
			refresh().catch(() => void 0);
		};
		load();
		const id = window.setInterval(load, 15e3);
		return () => {
			stop = true;
			window.clearInterval(id);
		};
	}, [user]);
	const symbols = draft.domain === "futures" ? FUTURES : draft.domain === "forex" ? FOREX : [];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "screen",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TopBar, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "screen-body wide",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "title-row",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "pill",
							children: "OPERATOR"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "h-display",
							children: "ADMIN"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "lede",
						children: "Post a signal here. The desk picks it up on the next refresh."
					}),
					isPending ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "lede",
						children: "Checking access…"
					}) : null,
					!isPending && !user ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "panel ready",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "SIGN IN TO POST" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "The operator desk is per account. The first person to claim it posts the signals everyone sees." }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/login",
								className: "nav-link is-active",
								children: "Sign in"
							})
						] })
					}) : null,
					user && !admin && openSeat ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "lock",
						onClick: () => {
							claimAdmin().then(() => {
								setAdmin(true);
								setOpenSeat(false);
							}).catch((error) => setNote(error instanceof Error ? error.message : "Could not claim"));
						},
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "lock-copy",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "CLAIM THE DESK" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "The first operator owns signal posting." })]
						})
					}) : null,
					user && !admin && !openSeat ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "lede",
						children: "This desk already has an operator."
					}) : null,
					admin ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
							className: "panel admin-form",
							onSubmit: (event) => {
								event.preventDefault();
								setNote("");
								saveSignal({ data: draft }).then(() => refresh()).then(() => {
									setDraft({
										...BLANK,
										domain: draft.domain,
										symbol: draft.domain === "futures" ? "BTC/USD" : ""
									});
									setNote("Signal is live on the desk.");
								}).catch((error) => setNote(error instanceof Error ? error.message : "Could not save"));
							},
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: "field",
									children: ["Domain", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
										value: draft.domain,
										onChange: (event) => {
											const domain = event.target.value;
											const symbol = domain === "futures" ? "BTC/USD" : domain === "forex" ? "EURUSD" : "";
											setDraft({
												...draft,
												domain,
												symbol,
												id: void 0
											});
										},
										children: DOMAINS.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: item.id,
											children: item.label
										}, item.id))
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: "field",
									children: ["Symbol", draft.domain === "degen" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										value: draft.symbol,
										onChange: (event) => setDraft({
											...draft,
											symbol: event.target.value.toUpperCase(),
											id: void 0
										}),
										placeholder: "PEPE"
									}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
										value: draft.symbol,
										onChange: (event) => setDraft({
											...draft,
											symbol: event.target.value,
											id: void 0
										}),
										children: symbols.map((symbol) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: symbol,
											children: symbol
										}, symbol))
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: "field",
									children: ["Direction", /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
										value: draft.direction,
										onChange: (event) => setDraft({
											...draft,
											direction: event.target.value
										}),
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "long",
											children: "Long"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "short",
											children: "Short"
										})]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: "field",
									children: ["Status", /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
										value: draft.status,
										onChange: (event) => setDraft({
											...draft,
											status: event.target.value
										}),
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "live",
												children: "Live"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "watching",
												children: "Watching"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "tp",
												children: "Target hit"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "stop",
												children: "Stopped"
											})
										]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: "field",
									children: ["Entry", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										inputMode: "decimal",
										value: draft.entry || "",
										onChange: (event) => setDraft({
											...draft,
											entry: Number(event.target.value)
										})
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: "field",
									children: ["Take profit", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										inputMode: "decimal",
										value: draft.tp || "",
										onChange: (event) => setDraft({
											...draft,
											tp: Number(event.target.value)
										})
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: "field",
									children: ["Stop", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										inputMode: "decimal",
										value: draft.sl || "",
										onChange: (event) => setDraft({
											...draft,
											sl: Number(event.target.value)
										})
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: "field",
									children: ["Confidence", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										inputMode: "numeric",
										value: draft.confidence,
										onChange: (event) => setDraft({
											...draft,
											confidence: Number(event.target.value)
										})
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: "field",
									children: ["Timeframe", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										value: draft.timeframe,
										onChange: (event) => setDraft({
											...draft,
											timeframe: event.target.value
										})
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: "field field-wide",
									children: ["Note", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
										rows: 3,
										value: draft.thesis,
										onChange: (event) => setDraft({
											...draft,
											thesis: event.target.value
										})
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "submit",
									className: "lock",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "lock-copy",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: draft.id ? "UPDATE SIGNAL" : "POST SIGNAL" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "It shows up on Modes as soon as the desk refreshes." })]
									})
								})
							]
						}),
						note ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "cap-note",
							children: note
						}) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "take-list",
							children: rows.map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
								className: "panel take-row",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: row.symbol }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
										row.domain,
										" · ",
										row.direction.toUpperCase(),
										" · ",
										row.status
									] })] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "ENTRY" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: row.entry })] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "TP / SL" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("b", { children: [
										row.tp,
										" / ",
										row.sl
									] })] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										className: "text-btn",
										onClick: () => setDraft({
											id: row.id,
											domain: row.domain,
											symbol: row.symbol,
											direction: row.direction,
											entry: row.entry,
											tp: row.tp,
											sl: row.sl,
											confidence: row.confidence,
											timeframe: row.timeframe,
											thesis: row.thesis,
											status: row.status
										}),
										children: "Edit"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										className: "text-btn",
										onClick: () => {
											retireSignal({ data: row.id }).then(() => refresh()).catch((error) => setNote(error instanceof Error ? error.message : "Could not pull"));
										},
										children: "Pull"
									})
								]
							}, row.id))
						})
					] }) : null
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Foot, {})
		]
	});
}
function BrainScreen() {
	const domain = useDesk((s) => s.domain);
	const nudge = useDesk((s) => s.nudge);
	const selectDomain = useDesk((s) => s.selectDomain);
	const start = useDesk((s) => s.start);
	const [shake, setShake] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		if (nudge === 0) return;
		setShake(true);
		const id = window.setTimeout(() => setShake(false), 460);
		return () => window.clearTimeout(id);
	}, [nudge]);
	(0, import_react.useEffect)(() => {
		const onKey = (event) => {
			if (event.target instanceof HTMLInputElement || event.target instanceof HTMLTextAreaElement) return;
			const next = {
				"1": "futures",
				"2": "forex",
				"3": "degen"
			}[event.key];
			if (next) {
				selectDomain(next);
				return;
			}
			if (event.key === "Enter") start();
		};
		window.addEventListener("keydown", onKey);
		return () => window.removeEventListener("keydown", onKey);
	}, [selectDomain, start]);
	const armed = DOMAINS.find((item) => item.id === domain);
	const readyClass = [
		"panel",
		"ready",
		domain === "degen" ? "is-degen" : "",
		shake ? "shake" : ""
	].filter(Boolean).join(" ");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "screen",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TopBar, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "screen-body",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "title-row",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "pill",
							children: "STATE 1"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "h-display",
							children: "SELECT MODE"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "lede",
						children: "Choose your trading domain."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "brain-stage",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								className: "brain-photo",
								src: "/brain.jpg",
								alt: "",
								draggable: false
							}),
							domain ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: `bloom bloom-${domain}` }) : null,
							DOMAINS.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: `lobe lobe-${item.id}`,
								"aria-pressed": domain === item.id,
								onClick: () => selectDomain(item.id),
								children: item.label
							}, item.id)),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: domain ? "start-btn is-armed" : "start-btn",
								onClick: start,
								children: "START"
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: readyClass,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "dot",
							"aria-hidden": "true"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: armed ? armed.armed.toUpperCase() : "READY TO LAUNCH" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: armed ? "START opens this trade setup." : "START opens the Futures setup. Pick a mode to switch it." })] })]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Foot, {})
		]
	});
}
var EMPTY = {
	taken: 0,
	open: 0,
	wins: 0,
	losses: 0,
	winRate: 0,
	netPnl: 0,
	rows: []
};
function DashboardScreen() {
	const { user, isPending } = useCurrentUserState();
	const [data, setData] = (0, import_react.useState)(EMPTY);
	const [note, setNote] = (0, import_react.useState)("");
	const [openSeat, setOpenSeat] = (0, import_react.useState)(false);
	const [admin, setAdmin] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		if (!user) return;
		let stop = false;
		const load = () => {
			myDashboard().then((next) => {
				if (!stop) setData(next);
			}).catch((error) => {
				if (!stop) setNote(error instanceof Error ? error.message : "Dashboard unavailable");
			});
			deskAccess().then((access) => {
				if (stop) return;
				setAdmin(access.admin);
				setOpenSeat(access.openSeat);
			}).catch(() => void 0);
		};
		load();
		const id = window.setInterval(load, 12e3);
		return () => {
			stop = true;
			window.clearInterval(id);
		};
	}, [user]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "screen",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TopBar, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "screen-body wide",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "title-row",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "pill",
							children: "PERFORMANCE"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "h-display",
							children: "DASHBOARD"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "lede",
						children: "Every take is yours. The live tape closes it when price tags the target or the stop."
					}),
					isPending ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "lede",
						children: "Checking your desk…"
					}) : null,
					!isPending && !user ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "panel ready",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "SIGN IN TO TRACK" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Signals you take stay on your account. Win, loss, and open P&L are marked from the live price." }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/login",
								className: "nav-link is-active",
								children: "Sign in"
							})
						] })
					}) : null,
					user && openSeat && !admin ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "lock",
						onClick: () => {
							claimAdmin().then(() => {
								setAdmin(true);
								setOpenSeat(false);
								setNote("You are the operator. Post signals from Admin.");
							}).catch((error) => setNote(error instanceof Error ? error.message : "Could not claim the desk"));
						},
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "lock-copy",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "CLAIM THE DESK" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "No operator yet. Claiming lets you post signals for everyone." })]
						})
					}) : null,
					user ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "dash-stats",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
									label: "TAKEN",
									value: String(data.taken)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
									label: "OPEN",
									value: String(data.open)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
									label: "WINS",
									value: String(data.wins)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
									label: "LOSSES",
									value: String(data.losses)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
									label: "WIN RATE",
									value: `${data.winRate.toFixed(0)}%`
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
									label: "NET P&L",
									value: formatUsd(data.netPnl),
									tone: data.netPnl >= 0 ? "up" : "dn"
								})
							]
						}),
						note ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "cap-note",
							children: note
						}) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "take-list",
							children: [data.rows.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "lede",
								children: "No signals taken yet. Lock one on the setup screen."
							}) : null, data.rows.map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
								className: "panel take-row",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: row.symbol }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
										row.direction.toUpperCase(),
										" · ",
										row.domain
									] })] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "ENTRY" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: formatQuote(row.entry, row.symbol) })] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: row.outcome ? "EXIT" : "MARK" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: formatQuote(row.outcome ? row.exitPrice ?? row.entry : row.mark ?? row.entry, row.symbol) })] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "P&L" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", {
										className: row.pnlUsd >= 0 ? "quote-up" : "quote-dn",
										children: formatUsd(row.pnlUsd)
									})] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: row.outcome === "win" ? "pill" : row.outcome === "loss" ? "pill is-stop" : "pill",
										children: row.outcome === "win" ? "PROFIT" : row.outcome === "loss" ? "LOSS" : "OPEN"
									})
								]
							}, row.id))]
						})
					] }) : null
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Foot, {})
		]
	});
}
function Stat({ label, value, tone }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "panel dash-stat",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: label }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", {
			className: tone === "up" ? "quote-up" : tone === "dn" ? "quote-dn" : void 0,
			children: value
		})]
	});
}
function SetupScreen() {
	const signalId = useDesk((s) => s.signalId);
	const equity = useDesk((s) => s.equity);
	const riskPct = useDesk((s) => s.riskPct);
	const caps = useDesk((s) => s.caps);
	const dailyStopPct = useDesk((s) => s.dailyStopPct);
	const openSignal = useDesk((s) => s.openSignal);
	const selectDomain = useDesk((s) => s.selectDomain);
	const setRiskPct = useDesk((s) => s.setRiskPct);
	const go = useDesk((s) => s.go);
	const bookRev = useDesk((s) => s.bookRev);
	const { user } = useCurrentUserState();
	const [openTake, setOpenTake] = (0, import_react.useState)(null);
	const [takeNote, setTakeNote] = (0, import_react.useState)("");
	const signal = getSignal(signalId);
	(0, import_react.useEffect)(() => {
		if (!signal) go("brain");
	}, [signal, go]);
	(0, import_react.useEffect)(() => {
		if (!signal) return;
		const list = signalsFor(signal.domain);
		const onKey = (event) => {
			if (event.target instanceof HTMLInputElement || event.target instanceof HTMLTextAreaElement) return;
			const index = list.findIndex((item) => item.id === signal.id);
			if (event.key === "ArrowRight") openSignal(list[(index + 1) % list.length].id);
			else if (event.key === "ArrowLeft") openSignal(list[(index - 1 + list.length) % list.length].id);
		};
		window.addEventListener("keydown", onKey);
		return () => window.removeEventListener("keydown", onKey);
	}, [signal, openSignal]);
	(0, import_react.useEffect)(() => {
		if (!user || !signal) {
			setOpenTake(null);
			return;
		}
		let stop = false;
		myDashboard().then((dash) => {
			if (stop) return;
			const row = dash.rows.find((item) => item.signalId === signal.id && item.outcome == null);
			setOpenTake(row?.id ?? null);
		}).catch(() => void 0);
		return () => {
			stop = true;
		};
	}, [
		user,
		signal,
		bookRev
	]);
	if (!signal) return null;
	const cap = caps[signal.domain];
	const applied = Math.min(riskPct, cap);
	const capped = riskPct - cap > .001;
	const rr = rewardRisk(signal);
	const units = unitSize(signal, equity, applied);
	const cash = riskCash(equity, applied);
	const notional = notionalUsd(signal, units);
	const leverage = impliedLeverage(notional, equity);
	const existing = openTake;
	const closed = signal.status === "tp" || signal.status === "stop";
	const book = signalsFor(signal.domain);
	const stopTight = applied > dailyStopPct + .001;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "screen",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TopBar, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "screen-body wide",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "title-row",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "pill",
							children: "STATE 2"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "h-display",
							children: "TRADE SETUP"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "lede",
						children: "Configure your risk. Trade with precision."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "setup-grid",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "area-radar",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Radar, {})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
								className: "panel instrument area-instrument",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: signal.symbol }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "pair-sub",
									children: DOMAINS.find((item) => item.id === signal.domain)?.label
								})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DomainMark, { domain: signal.domain })]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "area-stats",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "panel stats",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "stat-row",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "RISK / REWARD" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: formatRr(rr) })]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "stat-row",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "POSITION SIZE" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: formatPct(applied) })]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "stat-row",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "CONFIDENCE" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("b", { children: [signal.confidence, "%"] })]
											})
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
										className: "slider-label",
										children: ["Risk allocation", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											className: "slider",
											type: "range",
											min: .25,
											max: cap,
											step: .05,
											value: applied,
											"aria-valuetext": formatPct(applied),
											onChange: (event) => setRiskPct(Number(event.target.value))
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "size-line",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["Size ", /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("strong", { children: [
												formatUnits(units),
												" ",
												signal.sizeLabel
											] })] }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["Risk ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: formatUsd(cash) })] }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["Notional ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: formatUsd(notional) })] }),
											signal.domain === "degen" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["Implied ", /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("strong", { children: [leverage.toFixed(1), "×"] })] }) : null
										]
									}),
									capped ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "cap-note",
										children: [
											signal.market,
											" cap ",
											formatPct(cap),
											" is binding."
										]
									}) : null,
									stopTight ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "cap-note",
										children: [
											"This ticket pushes today past the ",
											formatPct(dailyStopPct),
											" daily stop."
										]
									}) : null
								]
							})
						]
					}),
					closed ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "lock",
						role: "status",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, {
							className: "lock-ico",
							strokeWidth: 1.5,
							"aria-hidden": "true"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "lock-copy",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: signal.status === "tp" ? "TARGET HIT" : "STOPPED OUT" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "This call is closed. It stays on the tape as a record." })]
						})]
					}) : existing ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "lock",
						role: "status",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, {
								className: "lock-ico",
								strokeWidth: 1.5,
								"aria-hidden": "true"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "lock-copy",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "SETUP LOCKED IN" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Manage risk. Protect capital. Stay disciplined." })]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "release",
								onClick: () => {
									releaseTake({ data: existing }).then(() => setOpenTake(null));
								},
								children: "Release"
							})
						]
					}) : user ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						className: "lock",
						onClick: () => {
							setTakeNote("");
							takeSignal({ data: {
								signalId: signal.id,
								riskPct: applied,
								equity
							} }).then((row) => setOpenTake(row.id)).catch((error) => setTakeNote(error instanceof Error ? error.message : "Could not take this signal"));
						},
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, {
							className: "lock-ico",
							strokeWidth: 1.5,
							"aria-hidden": "true"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "lock-copy",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "LOCK SETUP" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: takeNote || "Manage risk. Protect capital. Stay disciplined." })]
						})]
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/login",
						className: "lock",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, {
							className: "lock-ico",
							strokeWidth: 1.5,
							"aria-hidden": "true"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "lock-copy",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "SIGN IN TO TAKE IT" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Your dashboard records the take and marks profit or loss from the live price." })]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "tape",
						role: "tablist",
						"aria-label": "Signal domain",
						children: DOMAINS.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "chip",
							"aria-selected": item.id === signal.domain,
							"aria-pressed": item.id === signal.domain,
							onClick: () => openDomain(item.id),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "sym",
								children: item.label
							})
						}, item.id))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "tape",
						role: "listbox",
						"aria-label": `${signal.market} signals`,
						children: book.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							className: "chip",
							role: "option",
							"aria-selected": item.id === signal.id,
							"aria-pressed": item.id === signal.id,
							onClick: () => openSignal(item.id),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "sym",
								children: item.symbol
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: item.direction === "long" ? "dir dir-long" : "dir dir-short",
								children: item.direction === "long" ? "LONG" : "SHORT"
							})]
						}, item.id))
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Foot, {})
		]
	});
	function openDomain(id) {
		const first = rankSignals(signalsFor(id))[0];
		if (first) openSignal(first.id);
		else selectDomain(id);
	}
}
function Radar() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "radar-wrap",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "radar-visual",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "radar-disc",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "sweep" })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "ring ring-a" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "ring ring-b" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "ring ring-c" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "spoke spoke-tp" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "spoke spoke-sl" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "node node-tp",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowUp, {})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "node node-sl",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowDown, {})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "entry-node",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "entry-kicker",
						children: "ENTRY"
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
					className: "panel mini-card float-tp",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mini-kicker tp",
						children: "TP"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mini-name",
						children: "TAKE PROFIT"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
					className: "panel mini-card float-sl",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mini-kicker sl",
						children: "SL"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mini-name",
						children: "STOP LOSS"
					})]
				})
			]
		})
	});
}
function DomainMark({ domain }) {
	if (domain === "forex") return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		className: "mark-icon",
		viewBox: "0 0 48 32",
		"aria-hidden": "true",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
			cx: "18",
			cy: "16",
			r: "10",
			fill: "none",
			stroke: "currentColor",
			strokeWidth: "1.6"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
			cx: "30",
			cy: "16",
			r: "10",
			fill: "none",
			stroke: "currentColor",
			strokeWidth: "1.6"
		})]
	});
	if (domain === "futures") return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		className: "mark-icon",
		viewBox: "0 0 48 32",
		"aria-hidden": "true",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d: "M10 22V14",
				stroke: "currentColor",
				strokeWidth: "2.2",
				strokeLinecap: "round"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d: "M10 16h5v6",
				fill: "none",
				stroke: "currentColor",
				strokeWidth: "1.4"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d: "M22 22V8",
				stroke: "currentColor",
				strokeWidth: "2.2",
				strokeLinecap: "round"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d: "M17 10h5v8",
				fill: "none",
				stroke: "currentColor",
				strokeWidth: "1.4"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d: "M34 22V12",
				stroke: "currentColor",
				strokeWidth: "2.2",
				strokeLinecap: "round"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d: "M34 14h5v6",
				fill: "none",
				stroke: "currentColor",
				strokeWidth: "1.4"
			})
		]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
		className: "mark-icon",
		viewBox: "0 0 48 32",
		"aria-hidden": "true",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
			d: "M24 3.5 28.2 14H38l-8 6.1 3 10.4L24 24.6 15 30.5l3-10.4-8-6.1h9.8L24 3.5Z",
			fill: "none",
			stroke: "currentColor",
			strokeWidth: "1.4",
			strokeLinejoin: "round"
		})
	});
}
function ArrowUp() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
		viewBox: "0 0 24 24",
		"aria-hidden": "true",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
			d: "M12 18V6M12 6l-5 5M12 6l5 5",
			fill: "none",
			stroke: "currentColor",
			strokeWidth: "1.8",
			strokeLinecap: "round"
		})
	});
}
function ArrowDown() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
		viewBox: "0 0 24 24",
		"aria-hidden": "true",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
			d: "M12 6v12M12 18l-5-5M12 18l5-5",
			fill: "none",
			stroke: "currentColor",
			strokeWidth: "1.8",
			strokeLinecap: "round"
		})
	});
}
/** The signal book is the trade-setup cross. Land there for whichever domain is armed. */
function SignalsScreen() {
	const domain = useDesk((s) => s.domain);
	const openSignal = useDesk((s) => s.openSignal);
	const go = useDesk((s) => s.go);
	(0, import_react.useEffect)(() => {
		const first = rankSignals(signalsFor(domain ?? "futures"))[0];
		if (first) openSignal(first.id);
		else go("brain");
	}, [
		domain,
		openSignal,
		go
	]);
	return null;
}
function Desk() {
	const view = useDesk((s) => s.view);
	const setBook = useDesk((s) => s.setBook);
	(0, import_react.useEffect)(() => {
		useDesk.persist.rehydrate();
	}, []);
	(0, import_react.useEffect)(() => {
		let stop = false;
		const load = () => {
			listSignals().then((rows) => {
				if (!stop) setBook(rows);
			}).catch(() => void 0);
		};
		load();
		const id = window.setInterval(load, 12e3);
		return () => {
			stop = true;
			window.clearInterval(id);
		};
	}, [setBook]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "app-root",
		children: [
			view === "brain" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BrainScreen, {}),
			view === "signals" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SignalsScreen, {}),
			view === "setup" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SetupScreen, {}),
			view === "dashboard" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DashboardScreen, {}),
			view === "admin" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AdminScreen, {})
		]
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Desk, {});
}
//#endregion
export { Home as component };
