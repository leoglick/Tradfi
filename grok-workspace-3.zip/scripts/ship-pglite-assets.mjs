import { access, copyFile } from "node:fs/promises";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";

const root = join(dirname(fileURLToPath(import.meta.url)), "..");
const dest = join(root, ".vercel/output/functions/__server.func/_libs");
const src = join(root, "node_modules/@electric-sql/pglite/dist");

try {
  await access(join(dest, "electric-sql__pglite.mjs"));
} catch {
  process.exit(0);
}

for (const name of ["pglite.wasm", "pglite.data", "initdb.wasm"]) {
  await copyFile(join(src, name), join(dest, name));
}
