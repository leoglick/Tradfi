import { createFileRoute } from "@tanstack/react-router";
import { GROK_PROVIDERS, authEnabled, signIn } from "@/lib/auth/client";

export const Route = createFileRoute("/login")({ component: Login });

function Login() {
  return (
    <main className="grid min-h-screen place-items-center p-6">
      <div className="panel w-full max-w-sm space-y-3 p-6">
        <p className="pill">ACCOUNT</p>
        <h1 className="h-display text-[1.6rem]">SIGN IN</h1>
        <p className="lede">Your dashboard keeps the signals you take, and the tape marks them win or loss.</p>
        {authEnabled ? (
          GROK_PROVIDERS.map((provider) => (
            <button
              key={provider.providerId}
              type="button"
              className="lock"
              onClick={() => signIn(provider.providerId, { callbackURL: "/" })}
            >
              <span className="lock-copy">
                <strong>CONTINUE WITH {provider.label.toUpperCase()}</strong>
              </span>
            </button>
          ))
        ) : (
          <p className="lede">Sign-in is disabled.</p>
        )}
      </div>
    </main>
  );
}
