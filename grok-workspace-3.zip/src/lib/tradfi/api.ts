import { createServerFn } from "@tanstack/react-start";
import { authMiddleware } from "@/lib/auth/middleware";
import {
  SIGNALS,
  type Domain,
  type Direction,
  type Signal,
  type SignalStatus,
} from "@/lib/tradfi/model";
import { quoteSymbol, type Quote } from "@/lib/tradfi/quotes";

export type TakeView = {
  id: string;
  signalId: string;
  symbol: string;
  domain: Domain;
  direction: Direction;
  entry: number;
  tp: number;
  sl: number;
  decimals: number;
  riskPct: number;
  equity: number;
  takenAt: string;
  outcome: "win" | "loss" | null;
  exitPrice: number | null;
  pnlUsd: number;
  mark: number | null;
};

export type Dashboard = {
  taken: number;
  open: number;
  wins: number;
  losses: number;
  winRate: number;
  netPnl: number;
  rows: TakeView[];
};

export type SignalDraft = {
  id?: string;
  domain: Domain;
  symbol: string;
  direction: Direction;
  entry: number;
  tp: number;
  sl: number;
  confidence: number;
  timeframe: string;
  thesis: string;
  status: SignalStatus;
};

const FUTURES = ["BTC/USD", "ETH/USD", "SOL/USD"] as const;

type Sql = Awaited<ReturnType<typeof import("@/lib/db").getSql>>;

type SignalRow = {
  id: string;
  domain: Domain;
  symbol: string;
  market: string;
  direction: Direction;
  entry: number;
  tp: number;
  sl: number;
  confidence: number;
  timeframe: string;
  session: string;
  thesis: string;
  decimals: number;
  size_label: string;
  dollars_per_unit: number;
  notional_per_unit: number;
  status: SignalStatus;
  age_min: number;
  trigger: string;
};

function num(value: unknown) {
  const n = typeof value === "number" ? value : Number(value);
  return Number.isFinite(n) ? n : 0;
}

function toSignal(row: SignalRow): Signal {
  return {
    id: row.id,
    domain: row.domain,
    symbol: row.symbol,
    market: row.market,
    direction: row.direction,
    entry: num(row.entry),
    tp: num(row.tp),
    sl: num(row.sl),
    confidence: num(row.confidence),
    timeframe: row.timeframe,
    session: row.session,
    thesis: row.thesis,
    decimals: num(row.decimals),
    sizeLabel: row.size_label,
    dollarsPerUnit: num(row.dollars_per_unit),
    notionalPerUnit: num(row.notional_per_unit),
    status: row.status,
    ageMin: num(row.age_min),
    trigger: row.trigger,
  };
}

async function db() {
  const { getSql } = await import("@/lib/db");
  return getSql();
}

async function ensureSeed(sql: Sql) {
  const count = await sql<{ n: number }>`select count(*)::int as n from signals`;
  if (num(count[0]?.n) > 0) return;
  for (const row of SIGNALS) {
    await sql`
      insert into signals (
        id, domain, symbol, market, direction, entry, tp, sl, confidence, timeframe, session,
        thesis, decimals, size_label, dollars_per_unit, notional_per_unit, status, age_min, trigger
      ) values (
        ${row.id}, ${row.domain}, ${row.symbol}, ${row.market}, ${row.direction}, ${row.entry},
        ${row.tp}, ${row.sl}, ${row.confidence}, ${row.timeframe}, ${row.session}, ${row.thesis},
        ${row.decimals}, ${row.sizeLabel}, ${row.dollarsPerUnit}, ${row.notionalPerUnit},
        ${row.status}, ${row.ageMin}, ${row.trigger}
      )
    `;
  }
}

function specFor(domain: Domain, symbol: string, entry: number) {
  const known: Record<string, { decimals: number; dollarsPerUnit: number; sizeLabel: string; market: string; notional: number }> = {
    "BTC/USD": { decimals: 2, dollarsPerUnit: 1, sizeLabel: "BTC", market: "Futures", notional: entry },
    "ETH/USD": { decimals: 2, dollarsPerUnit: 1, sizeLabel: "ETH", market: "Futures", notional: entry },
    "SOL/USD": { decimals: 2, dollarsPerUnit: 1, sizeLabel: "SOL", market: "Futures", notional: entry },
    EURUSD: { decimals: 5, dollarsPerUnit: 100000, sizeLabel: "lots", market: "Forex", notional: 100000 * entry },
    GBPUSD: { decimals: 5, dollarsPerUnit: 100000, sizeLabel: "lots", market: "Forex", notional: 100000 * entry },
    AUDUSD: { decimals: 5, dollarsPerUnit: 100000, sizeLabel: "lots", market: "Forex", notional: 100000 * entry },
    NZDUSD: { decimals: 5, dollarsPerUnit: 100000, sizeLabel: "lots", market: "Forex", notional: 100000 * entry },
    USDJPY: { decimals: 3, dollarsPerUnit: 100000 / Math.max(entry, 1), sizeLabel: "lots", market: "Forex", notional: 100000 },
    USDCAD: { decimals: 5, dollarsPerUnit: 100000, sizeLabel: "lots", market: "Forex", notional: 100000 },
    XAUUSD: { decimals: 2, dollarsPerUnit: 1, sizeLabel: "oz", market: "Forex", notional: entry },
  };
  const hit = known[symbol];
  if (hit) return hit;
  if (domain === "futures") throw new Error("Futures signals are only BTC/USD, ETH/USD, and SOL/USD.");
  const decimals = entry >= 100 ? 2 : entry >= 1 ? 4 : 8;
  return {
    decimals,
    dollarsPerUnit: 1,
    sizeLabel: symbol,
    market: domain === "forex" ? "Forex" : "Perp",
    notional: entry,
  };
}

function parseDraft(input: unknown): SignalDraft {
  if (!input || typeof input !== "object") throw new Error("Missing signal");
  const row = input as Record<string, unknown>;
  const domain = row.domain;
  const direction = row.direction;
  const status = row.status;
  if (domain !== "futures" && domain !== "forex" && domain !== "degen") throw new Error("Pick a domain");
  if (direction !== "long" && direction !== "short") throw new Error("Pick a direction");
  if (status !== "live" && status !== "watching" && status !== "tp" && status !== "stop") throw new Error("Pick a status");
  const symbol = String(row.symbol ?? "")
    .trim()
    .toUpperCase()
    .replace(/\s/g, "");
  if (!symbol) throw new Error("Symbol is required");
  if (domain === "futures" && !FUTURES.includes(symbol as (typeof FUTURES)[number])) {
    throw new Error("Futures signals are only BTC/USD, ETH/USD, and SOL/USD.");
  }
  const entry = num(row.entry);
  const tp = num(row.tp);
  const sl = num(row.sl);
  const confidence = Math.round(num(row.confidence));
  if (entry <= 0 || tp <= 0 || sl <= 0) throw new Error("Entry, target, and stop must be prices");
  if (Math.abs(entry - sl) === 0) throw new Error("Stop cannot sit on the entry");
  if (confidence < 1 || confidence > 99) throw new Error("Confidence is 1 to 99");
  const thesis = String(row.thesis ?? "").trim();
  if (thesis.length < 8) throw new Error("Add a short note so the desk knows why");
  const timeframe = String(row.timeframe ?? "1H").trim() || "1H";
  return {
    id: typeof row.id === "string" && row.id ? row.id : undefined,
    domain,
    symbol,
    direction,
    entry,
    tp,
    sl,
    confidence,
    timeframe,
    thesis,
    status,
  };
}

async function isAdmin(sql: Sql, userId: string) {
  const rows = await sql<{ user_id: string }>`select user_id from admins where user_id = ${userId}`;
  return rows.length > 0;
}

let cachedQuotes: Quote[] = [];
let cachedAt = 0;
const sessionOpen = new Map<string, number>();

function stamp(rows: Quote[]) {
  return rows.map((row) => {
    if (row.changePct != null) return row;
    const open = sessionOpen.get(row.symbol);
    if (open == null) {
      sessionOpen.set(row.symbol, row.price);
      return { ...row, changePct: 0 };
    }
    return { ...row, changePct: ((row.price - open) / open) * 100 };
  });
}

async function krakenCrypto(): Promise<Quote[]> {
  const res = await fetch("https://api.kraken.com/0/public/Ticker?pair=XBTUSD,ETHUSD,SOLUSD", {
    signal: AbortSignal.timeout(6000),
  });
  if (!res.ok) throw new Error("crypto feed down");
  const body = (await res.json()) as { result?: Record<string, { c?: string[]; o?: string }> };
  const result = body.result ?? {};
  const want = [
    { symbol: "BTC/USD", test: (key: string) => key.includes("XBT") },
    { symbol: "ETH/USD", test: (key: string) => key.includes("ETH") },
    { symbol: "SOL/USD", test: (key: string) => key.includes("SOL") },
  ];
  const out: Quote[] = [];
  for (const item of want) {
    const key = Object.keys(result).find(item.test);
    if (!key) continue;
    const last = num(result[key]?.c?.[0]);
    const open = num(result[key]?.o);
    if (last <= 0) continue;
    out.push({
      symbol: item.symbol,
      price: last,
      changePct: open > 0 ? ((last - open) / open) * 100 : null,
      kind: "crypto",
    });
  }
  return out;
}

async function coinbaseSpot(pair: string, symbol: string): Promise<Quote | null> {
  const res = await fetch(`https://api.coinbase.com/v2/prices/${pair}/spot`, {
    signal: AbortSignal.timeout(6000),
  });
  if (!res.ok) return null;
  const body = (await res.json()) as { data?: { amount?: string } };
  const price = num(body.data?.amount);
  if (price <= 0) return null;
  return { symbol, price, changePct: null, kind: "crypto" };
}

async function cryptoQuotes(): Promise<Quote[]> {
  try {
    const rows = await krakenCrypto();
    if (rows.length >= 3) return rows;
  } catch {
    /* fall through */
  }
  const pairs: Array<[string, string]> = [
    ["BTC-USD", "BTC/USD"],
    ["ETH-USD", "ETH/USD"],
    ["SOL-USD", "SOL/USD"],
  ];
  const settled = await Promise.all(pairs.map(([pair, symbol]) => coinbaseSpot(pair, symbol)));
  return settled.filter((row): row is Quote => row != null);
}

async function forexQuotes(): Promise<Quote[]> {
  const res = await fetch("https://api.frankfurter.dev/v1/latest?from=USD&to=EUR,GBP,JPY,AUD,CAD,NZD", {
    signal: AbortSignal.timeout(6000),
  });
  if (!res.ok) return [];
  const body = (await res.json()) as { rates?: Record<string, number> };
  const rates = body.rates ?? {};
  const out: Quote[] = [];
  const push = (symbol: string, price: number) => {
    if (price > 0) out.push({ symbol, price, changePct: null, kind: "forex" });
  };
  if (rates.EUR) push("EUR/USD", 1 / rates.EUR);
  if (rates.GBP) push("GBP/USD", 1 / rates.GBP);
  if (rates.JPY) push("USD/JPY", rates.JPY);
  if (rates.AUD) push("AUD/USD", 1 / rates.AUD);
  if (rates.CAD) push("USD/CAD", rates.CAD);
  if (rates.NZD) push("NZD/USD", 1 / rates.NZD);
  return out;
}

async function loadQuotes() {
  if (Date.now() - cachedAt < 5000 && cachedQuotes.length > 0) return cachedQuotes;
  const [crypto, forex] = await Promise.allSettled([cryptoQuotes(), forexQuotes()]);
  const rows = [
    ...(crypto.status === "fulfilled" ? crypto.value : []),
    ...(forex.status === "fulfilled" ? forex.value : []),
  ];
  if (rows.length > 0) {
    cachedQuotes = stamp(rows);
    cachedAt = Date.now();
  }
  return cachedQuotes;
}

function markOf(symbol: string, quotes: Quote[]) {
  const key = quoteSymbol(symbol);
  if (!key) return null;
  return quotes.find((quote) => quote.symbol === key)?.price ?? null;
}

function unitsOf(entry: number, sl: number, equity: number, riskPct: number, dollarsPerUnit: number) {
  const stop = Math.abs(entry - sl);
  if (stop === 0 || dollarsPerUnit === 0) return 0;
  return (equity * (riskPct / 100)) / (stop * dollarsPerUnit);
}

function pnlOf(direction: Direction, entry: number, exit: number, units: number, dollarsPerUnit: number) {
  const move = direction === "long" ? exit - entry : entry - exit;
  return move * dollarsPerUnit * units;
}

type TakeRow = {
  id: string;
  signal_id: string;
  symbol: string;
  domain: Domain;
  direction: Direction;
  entry: number;
  tp: number;
  sl: number;
  decimals: number;
  risk_pct: number;
  equity: number;
  dollars_per_unit: number;
  taken_at: string | Date;
  outcome: string | null;
  exit_price: number | null;
  pnl_usd: number | null;
};

function present(row: TakeRow, mark: number | null): TakeView {
  const entry = num(row.entry);
  const tp = num(row.tp);
  const sl = num(row.sl);
  const dollars = num(row.dollars_per_unit);
  const units = unitsOf(entry, sl, num(row.equity), num(row.risk_pct), dollars);
  const outcome = row.outcome === "win" || row.outcome === "loss" ? row.outcome : null;
  const exitPrice = row.exit_price == null ? null : num(row.exit_price);
  const pnl = outcome && exitPrice != null ? pnlOf(row.direction, entry, exitPrice, units, dollars) : mark != null ? pnlOf(row.direction, entry, mark, units, dollars) : 0;
  return {
    id: row.id,
    signalId: row.signal_id,
    symbol: row.symbol,
    domain: row.domain,
    direction: row.direction,
    entry,
    tp,
    sl,
    decimals: num(row.decimals),
    riskPct: num(row.risk_pct),
    equity: num(row.equity),
    takenAt: new Date(row.taken_at).toISOString(),
    outcome,
    exitPrice,
    pnlUsd: pnl,
    mark,
  };
}

export const getQuotes = createServerFn({ method: "GET" }).handler(async () => loadQuotes());

export const listSignals = createServerFn({ method: "GET" }).handler(async () => {
  const sql = await db();
  await ensureSeed(sql);
  const rows = await sql<SignalRow>`
    select id, domain, symbol, market, direction, entry, tp, sl, confidence, timeframe, session,
           thesis, decimals, size_label, dollars_per_unit, notional_per_unit, status, age_min, trigger
    from signals
    where active = true
    order by updated_at desc
  `;
  return rows.map(toSignal);
});

export const deskAccess = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => {
    const sql = await db();
    const mine = await isAdmin(sql, context.userId);
    const all = await sql<{ n: number }>`select count(*)::int as n from admins`;
    return { admin: mine, openSeat: num(all[0]?.n) === 0 };
  });

export const claimAdmin = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => {
    const sql = await db();
    const all = await sql<{ n: number }>`select count(*)::int as n from admins`;
    if (num(all[0]?.n) > 0) {
      const mine = await isAdmin(sql, context.userId);
      if (!mine) throw new Error("This desk already has an operator");
      return { admin: true };
    }
    await sql`insert into admins (user_id) values (${context.userId})`;
    return { admin: true };
  });

export const saveSignal = createServerFn({ method: "POST" })
  .validator(parseDraft)
  .middleware([authMiddleware])
  .handler(async ({ context, data }) => {
    const sql = await db();
    if (!(await isAdmin(sql, context.userId))) throw new Error("Only the operator can post signals");
    const spec = specFor(data.domain, data.symbol, data.entry);
    const id =
      data.id ??
      `${data.domain}-${data.symbol.toLowerCase().replace(/[^a-z0-9]+/g, "")}-${Date.now().toString(36)}`;
    await sql`
      insert into signals (
        id, domain, symbol, market, direction, entry, tp, sl, confidence, timeframe, session,
        thesis, decimals, size_label, dollars_per_unit, notional_per_unit, status, age_min, trigger, active, updated_at
      ) values (
        ${id}, ${data.domain}, ${data.symbol}, ${spec.market}, ${data.direction}, ${data.entry}, ${data.tp},
        ${data.sl}, ${data.confidence}, ${data.timeframe}, ${"UTC"}, ${data.thesis}, ${spec.decimals},
        ${spec.sizeLabel}, ${spec.dollarsPerUnit}, ${spec.notional}, ${data.status}, ${0}, ${"Manual"}, true, now()
      )
      on conflict (id) do update set
        domain = excluded.domain,
        symbol = excluded.symbol,
        market = excluded.market,
        direction = excluded.direction,
        entry = excluded.entry,
        tp = excluded.tp,
        sl = excluded.sl,
        confidence = excluded.confidence,
        timeframe = excluded.timeframe,
        thesis = excluded.thesis,
        decimals = excluded.decimals,
        size_label = excluded.size_label,
        dollars_per_unit = excluded.dollars_per_unit,
        notional_per_unit = excluded.notional_per_unit,
        status = excluded.status,
        active = true,
        updated_at = now()
    `;
    return { id };
  });

export const retireSignal = createServerFn({ method: "POST" })
  .validator((id: string) => {
    if (!id) throw new Error("Missing signal");
    return id;
  })
  .middleware([authMiddleware])
  .handler(async ({ context, data: id }) => {
    const sql = await db();
    if (!(await isAdmin(sql, context.userId))) throw new Error("Only the operator can pull a signal");
    await sql`update signals set active = false, updated_at = now() where id = ${id}`;
    return { id };
  });

export const takeSignal = createServerFn({ method: "POST" })
  .validator((input: { signalId: string; riskPct: number; equity: number }) => {
    if (!input?.signalId) throw new Error("Missing signal");
    const riskPct = num(input.riskPct);
    const equity = num(input.equity);
    if (riskPct <= 0 || equity <= 0) throw new Error("Set equity and risk before you take it");
    return { signalId: input.signalId, riskPct, equity };
  })
  .middleware([authMiddleware])
  .handler(async ({ context, data }) => {
    const sql = await db();
    const rows = await sql<SignalRow>`
      select id, domain, symbol, market, direction, entry, tp, sl, confidence, timeframe, session,
             thesis, decimals, size_label, dollars_per_unit, notional_per_unit, status, age_min, trigger
      from signals where id = ${data.signalId} and active = true
    `;
    const signal = rows[0];
    if (!signal) throw new Error("That signal is no longer on the desk");
    if (signal.status === "tp" || signal.status === "stop") throw new Error("That call is already closed");
    const open = await sql<{ id: string }>`
      select id from takes where user_id = ${context.userId} and signal_id = ${signal.id} and outcome is null
    `;
    if (open.length > 0) return { id: open[0]!.id };
    const id = crypto.randomUUID();
    await sql`
      insert into takes (
        id, user_id, signal_id, symbol, domain, direction, entry, tp, sl, decimals,
        risk_pct, equity, dollars_per_unit, size_label
      ) values (
        ${id}, ${context.userId}, ${signal.id}, ${signal.symbol}, ${signal.domain}, ${signal.direction},
        ${num(signal.entry)}, ${num(signal.tp)}, ${num(signal.sl)}, ${num(signal.decimals)},
        ${data.riskPct}, ${data.equity}, ${num(signal.dollars_per_unit)}, ${signal.size_label}
      )
    `;
    return { id };
  });

export const releaseTake = createServerFn({ method: "POST" })
  .validator((id: string) => {
    if (!id) throw new Error("Missing take");
    return id;
  })
  .middleware([authMiddleware])
  .handler(async ({ context, data: id }) => {
    const sql = await db();
    await sql`delete from takes where id = ${id} and user_id = ${context.userId} and outcome is null`;
    return { id };
  });

export const myDashboard = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }): Promise<Dashboard> => {
    const sql = await db();
    const quotes = await loadQuotes();
    const rows = await sql<TakeRow>`
      select id, signal_id, symbol, domain, direction, entry, tp, sl, decimals, risk_pct, equity,
             dollars_per_unit, taken_at, outcome, exit_price, pnl_usd
      from takes
      where user_id = ${context.userId}
      order by taken_at desc
    `;
    for (const row of rows) {
      if (row.outcome === "win" || row.outcome === "loss") continue;
      const mark = markOf(row.symbol, quotes);
      if (mark == null) continue;
      const entry = num(row.entry);
      const tp = num(row.tp);
      const sl = num(row.sl);
      const hitTp = row.direction === "long" ? mark >= tp : mark <= tp;
      const hitSl = row.direction === "long" ? mark <= sl : mark >= sl;
      if (!hitTp && !hitSl) continue;
      const outcome = hitTp ? "win" : "loss";
      const exitPrice = hitTp ? tp : sl;
      const dollars = num(row.dollars_per_unit);
      const units = unitsOf(entry, sl, num(row.equity), num(row.risk_pct), dollars);
      const pnl = pnlOf(row.direction, entry, exitPrice, units, dollars);
      await sql`
        update takes
        set outcome = ${outcome}, exit_price = ${exitPrice}, pnl_usd = ${pnl}, closed_at = now()
        where id = ${row.id} and user_id = ${context.userId} and outcome is null
      `;
      row.outcome = outcome;
      row.exit_price = exitPrice;
      row.pnl_usd = pnl;
    }
    const views = rows.map((row) => present(row, row.outcome ? null : markOf(row.symbol, quotes)));
    const wins = views.filter((row) => row.outcome === "win").length;
    const losses = views.filter((row) => row.outcome === "loss").length;
    const closed = wins + losses;
    return {
      taken: views.length,
      open: views.filter((row) => row.outcome == null).length,
      wins,
      losses,
      winRate: closed === 0 ? 0 : (wins / closed) * 100,
      netPnl: views.reduce((sum, row) => sum + row.pnlUsd, 0),
      rows: views,
    };
  });
