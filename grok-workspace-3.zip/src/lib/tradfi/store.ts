import { create } from "zustand";
import { createJSONStorage, persist } from "zustand/middleware";
import { type Domain, getSignal, installBook, rankSignals, rewardRisk, signalsFor, type Signal } from "@/lib/tradfi/model";

export type LockedSetup = {
  id: string;
  signalId: string;
  domain: Domain;
  symbol: string;
  market: string;
  direction: "long" | "short";
  entry: number;
  tp: number;
  sl: number;
  decimals: number;
  rr: number;
  confidence: number;
  riskPct: number;
  equity: number;
  timeframe: string;
  thesis: string;
  lockedAt: number;
};

type View = "brain" | "signals" | "setup" | "dashboard" | "admin";

type DeskState = {
  view: View;
  domain: Domain | null;
  signalId: string | null;
  equity: number;
  riskPct: number;
  dailyStopPct: number;
  caps: Record<Domain, number>;
  locked: LockedSetup[];
  nudge: number;
  bookRev: number;
  setBook: (rows: Signal[]) => void;
  selectDomain: (domain: Domain) => void;
  start: () => void;
  openSignal: (id: string) => void;
  setRiskPct: (n: number) => void;
  setEquity: (n: number) => void;
  setDailyStop: (n: number) => void;
  setCap: (domain: Domain, n: number) => void;
  lockCurrent: () => void;
  removeLocked: (id: string) => void;
  go: (view: View) => void;
  poke: () => void;
};

const DEFAULT_CAPS: Record<Domain, number> = {
  futures: 2,
  forex: 1.5,
  degen: 0.5,
};

export const useDesk = create<DeskState>()(
  persist(
    (set, get) => ({
      view: "brain",
      domain: null,
      signalId: null,
      equity: 25000,
      riskPct: 1.25,
      dailyStopPct: 4,
      caps: DEFAULT_CAPS,
      locked: [],
      nudge: 0,
      bookRev: 0,
      setBook: (rows) => {
        installBook(rows);
        set((s) => ({ bookRev: s.bookRev + 1 }));
      },
      selectDomain: (domain) => set({ domain }),
      poke: () => set((s) => ({ nudge: s.nudge + 1 })),
      start: () => {
        const domain = get().domain ?? "futures";
        const first = rankSignals(signalsFor(domain))[0];
        set({ domain, view: "setup", signalId: first?.id ?? null });
      },
      openSignal: (id) => {
        const signal = getSignal(id);
        if (!signal) return;
        set({ view: "setup", domain: signal.domain, signalId: signal.id });
      },
      setRiskPct: (n) => set({ riskPct: clamp(n, 0.25, 3) }),
      setEquity: (n) => set({ equity: clamp(n, 100, 100_000_000) }),
      setDailyStop: (n) => set({ dailyStopPct: clamp(n, 0.5, 10) }),
      setCap: (domain, n) =>
        set((s) => ({
          caps: { ...s.caps, [domain]: clamp(n, 0.25, 3) },
        })),
      lockCurrent: () => {
        const { signalId, riskPct, equity, caps, locked } = get();
        const signal = getSignal(signalId);
        if (!signal) return;
        if (signal.status === "tp" || signal.status === "stop") return;
        if (locked.some((row) => row.signalId === signal.id)) return;
        const applied = Math.min(riskPct, caps[signal.domain]);
        const row: LockedSetup = {
          id: crypto.randomUUID(),
          signalId: signal.id,
          domain: signal.domain,
          symbol: signal.symbol,
          market: signal.market,
          direction: signal.direction,
          entry: signal.entry,
          tp: signal.tp,
          sl: signal.sl,
          decimals: signal.decimals,
          rr: rewardRisk(signal),
          confidence: signal.confidence,
          riskPct: applied,
          equity,
          timeframe: signal.timeframe,
          thesis: signal.thesis,
          lockedAt: Date.now(),
        };
        set({ locked: [row, ...locked] });
      },
      removeLocked: (id) => set((s) => ({ locked: s.locked.filter((row) => row.id !== id) })),
      go: (view) => set({ view }),
    }),
    {
      name: "traderedge-desk",
      storage: createJSONStorage(() => localStorage),
      skipHydration: true,
      version: 1,
      partialize: (s) => ({
        equity: s.equity,
        riskPct: s.riskPct,
        dailyStopPct: s.dailyStopPct,
        caps: s.caps,
        locked: s.locked,
      }),
    },
  ),
);

function clamp(n: number, min: number, max: number) {
  if (Number.isNaN(n)) return min;
  return Math.min(max, Math.max(min, n));
}
