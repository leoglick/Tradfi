create table if not exists signals (
  id text primary key,
  domain text not null,
  symbol text not null,
  market text not null,
  direction text not null,
  entry double precision not null,
  tp double precision not null,
  sl double precision not null,
  confidence integer not null,
  timeframe text not null,
  session text not null default 'UTC',
  thesis text not null,
  decimals integer not null,
  size_label text not null,
  dollars_per_unit double precision not null,
  notional_per_unit double precision not null,
  status text not null,
  age_min integer not null default 0,
  trigger text not null default '',
  active boolean not null default true,
  updated_at timestamptz not null default now()
);

create table if not exists takes (
  id text primary key,
  user_id text not null,
  signal_id text not null,
  symbol text not null,
  domain text not null,
  direction text not null,
  entry double precision not null,
  tp double precision not null,
  sl double precision not null,
  decimals integer not null,
  risk_pct double precision not null,
  equity double precision not null,
  dollars_per_unit double precision not null,
  size_label text not null,
  taken_at timestamptz not null default now(),
  outcome text,
  exit_price double precision,
  pnl_usd double precision,
  closed_at timestamptz
);

create index if not exists takes_user_idx on takes (user_id, taken_at desc);

create table if not exists admins (
  user_id text primary key,
  created_at timestamptz not null default now()
);
